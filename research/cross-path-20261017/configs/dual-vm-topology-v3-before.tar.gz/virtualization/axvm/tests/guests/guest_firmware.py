"""Shared selection of explicit virtual Guest firmware for both preparers."""

import os


def explicit_enabled():
    value = os.environ.get('VIRQ_EXPLICIT_DTB', '0')
    if value not in ('0', '1'):
        raise ValueError('VIRQ_EXPLICIT_DTB must be 0 or 1')
    return value == '1'


def gic_layout():
    value = os.environ.get('VIRQ_GIC_LAYOUT', 'qemu')
    if value not in ('qemu', 'rk3588'):
        raise ValueError('VIRQ_GIC_LAYOUT must be qemu or rk3588')
    if value == 'rk3588' and not explicit_enabled():
        raise ValueError('RK3588 GIC layout requires explicit Guest firmware')
    return value
