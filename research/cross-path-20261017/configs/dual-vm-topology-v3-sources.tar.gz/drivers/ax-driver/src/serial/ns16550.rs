use alloc::format;

use log::info;
#[cfg(target_arch = "x86_64")]
use rdrive::probe::acpi::AcpiResourceAddress;
use rdrive::{
    probe::{
        OnProbeError,
        acpi::{AcpiId, AcpiInfo, ProbeAcpi},
    },
    register::ProbeFdt,
};
use some_serial::ns16550 as serial_ns16550;

#[cfg(target_arch = "x86_64")]
use super::BindingIrq;
use super::{
    PlatformSerialDevice, ProbedUart, acpi_serial_device_info, erase_uart, prop_u32,
    serial_device_info,
};

const ACPI_NS16550_CLOCK: u32 = 1_843_200;
const ACPI_NS16550_REG_WIDTH: usize = 1;
#[cfg(target_arch = "x86_64")]
const LEGACY_COM1_PORT: u16 = 0x3f8;
#[cfg(target_arch = "x86_64")]
const LEGACY_COM1_ISA_IRQ: u8 = 4;

model_register!(
    name: "NS16550 serial",
    level: ProbeLevel::PreKernel,
    priority: ProbePriority::DEFAULT,
    probe_kinds: &[
        ProbeKind::Fdt {
            compatibles: &["snps,dw-apb-uart", "ns16550a", "ns16550"],
            on_probe: probe
        },
        ProbeKind::Acpi {
            ids: &[
                AcpiId {
                    hid: "PNP0501",
                    cids: &[],
                },
                AcpiId {
                    hid: "PNP0500",
                    cids: &[],
                },
            ],
            on_probe: probe_acpi
        },
        #[cfg(target_arch = "x86_64")]
        ProbeKind::Acpi {
            ids: &[],
            on_probe: probe_legacy_com1
        },
    ],
);

#[cfg(target_arch = "x86_64")]
fn probe_legacy_com1(probe: ProbeAcpi<'_>) -> Result<(), OnProbeError> {
    let route = probe
        .info()
        .root
        .routing()
        .resolve_isa_irq(LEGACY_COM1_ISA_IRQ)
        .ok_or_else(|| OnProbeError::other("legacy COM1 IRQ4 has no ACPI I/O APIC route"))?;
    let serial = erase_uart(serial_ns16550::Ns16550::new_port(
        LEGACY_COM1_PORT,
        ACPI_NS16550_CLOCK,
    ));

    info!("Legacy x86 COM1 fallback registered successfully");
    probe.register_root_resource_device(
        AcpiResourceAddress::io(u64::from(LEGACY_COM1_PORT)),
        PlatformSerialDevice::new(
            serial,
            "legacy/com1".into(),
            Some(0),
            usize::from(LEGACY_COM1_PORT),
            Some(BindingIrq::from(route)),
        ),
    );
    Ok(())
}

fn probe(probe: ProbeFdt<'_>) -> Result<(), OnProbeError> {
    let (info, plat_dev) = probe.into_parts();

    info!("Probing NS16550 serial device: {}", info.node.name());
    let base_reg = info
        .node
        .regs()
        .into_iter()
        .next()
        .ok_or_else(|| OnProbeError::other(format!("[{}] has no reg", info.node.name())))?;

    let mmio_size = base_reg.size.unwrap_or(0x1000) as usize;
    let mmio_base = crate::mmio::iomap(base_reg.address as usize, mmio_size)?;
    let node = info.node.as_node();
    let reg_width = prop_u32(node, "reg-io-width").unwrap_or(1) as usize;
    let reg_shift = prop_u32(node, "reg-shift").map(|shift| 1usize << shift);
    let ns16550_width = reg_shift.unwrap_or(reg_width);
    let mut serial: Option<ProbedUart> = None;

    for compatible in node.compatibles() {
        if compatible == "snps,dw-apb-uart" {
            let default_clock = if node
                .compatibles()
                .any(|compatible| compatible == "rockchip,rk3588-uart")
            {
                serial_ns16550::dw_apb::RK3588_UART_CLOCK
            } else {
                serial_ns16550::dw_apb::SG2002_UART_CLOCK
            };
            let clock_freq = prop_u32(node, "clock-frequency").unwrap_or(default_clock);
            let raw = serial_ns16550::DwApbUart::new_raw(mmio_base, clock_freq);
            serial = Some(erase_uart(raw));
            break;
        }

        if matches!(compatible, "ns16550a" | "ns16550") {
            let clock_freq = prop_u32(node, "clock-frequency").unwrap_or(24_000_000);
            let raw = serial_ns16550::Ns16550::new_mmio(mmio_base, clock_freq, ns16550_width);
            serial = Some(erase_uart(raw));
            break;
        }
    }

    let serial = serial.ok_or(OnProbeError::NotMatch)?;
    let device_info = serial_device_info(&info, &base_reg);

    info!(
        "NS16550 serial@{:#x} registered successfully",
        serial.hardware.register_base
    );
    plat_dev.register(PlatformSerialDevice::new(
        serial,
        device_info.path,
        device_info.alias_index,
        device_info.paddr,
        device_info.irq,
    ));
    Ok(())
}

struct AcpiSerialResource {
    serial: ProbedUart,
    paddr: usize,
}

fn probe_acpi(probe: ProbeAcpi<'_>) -> Result<(), OnProbeError> {
    let info = probe.info();

    info!("Probing ACPI NS16550 serial device: {}", info.path);
    let resource = if let Some(resource) = acpi_io_serial(info)? {
        resource
    } else {
        acpi_mmio_serial(info)?
    };
    let device_info = acpi_serial_device_info(info, resource.paddr);
    let plat_dev = probe.into_platform_device();

    info!(
        "ACPI NS16550 serial@{:#x} registered successfully",
        resource.paddr
    );
    plat_dev.register(PlatformSerialDevice::new(
        resource.serial,
        device_info.path,
        device_info.alias_index,
        device_info.paddr,
        device_info.irq,
    ));
    Ok(())
}

#[cfg(any(target_arch = "x86", target_arch = "x86_64"))]
fn acpi_io_serial(info: &AcpiInfo<'_>) -> Result<Option<AcpiSerialResource>, OnProbeError> {
    let Some(range) = info.io_ranges().first() else {
        return Ok(None);
    };
    let port = u16::try_from(range.base).map_err(|_| {
        OnProbeError::other(format!(
            "{} has invalid ACPI serial I/O base {:#x}",
            info.path, range.base
        ))
    })?;
    let raw = serial_ns16550::Ns16550::new_port(port, ACPI_NS16550_CLOCK);
    let serial = erase_uart(raw);
    Ok(Some(AcpiSerialResource {
        serial,
        paddr: usize::from(port),
    }))
}

#[cfg(not(any(target_arch = "x86", target_arch = "x86_64")))]
fn acpi_io_serial(_info: &AcpiInfo<'_>) -> Result<Option<AcpiSerialResource>, OnProbeError> {
    Ok(None)
}

fn acpi_mmio_serial(info: &AcpiInfo<'_>) -> Result<AcpiSerialResource, OnProbeError> {
    let range = info.memory_ranges().first().ok_or_else(|| {
        OnProbeError::other(format!(
            "{} has no ACPI serial I/O port or MMIO resource",
            info.path
        ))
    })?;
    let paddr = usize::try_from(range.base).map_err(|_| {
        OnProbeError::other(format!(
            "{} has invalid ACPI serial MMIO base {:#x}",
            info.path, range.base
        ))
    })?;
    let mmio_size = usize::try_from(range.size).unwrap_or(0x1000).max(0x1000);
    let mmio_base = crate::mmio::iomap(paddr, mmio_size)?;
    let raw =
        serial_ns16550::Ns16550::new_mmio(mmio_base, ACPI_NS16550_CLOCK, ACPI_NS16550_REG_WIDTH);
    let serial = erase_uart(raw);
    Ok(AcpiSerialResource { serial, paddr })
}
