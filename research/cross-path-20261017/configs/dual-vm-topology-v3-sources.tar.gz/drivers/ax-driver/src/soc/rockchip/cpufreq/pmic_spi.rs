// Copyright 2025 The Axvisor Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

//! RK3588 A55 (`vdd_cpu_lit`) CPU-rail voltage lever — RK806 PMIC over SPI2.
//!
//! The RK3588 A55 clock is voltage-coupled, so each OPP needs the CPU rail
//! voltage that only the PMIC can set. On the OrangePi-5-Plus the
//! A55 rail `vdd_cpu_lit_s0` is provided by an **RK806** PMIC on **SPI2**
//! (`spi@feb20000`, chip-select 0). This module is a minimal polling SPI master
//! plus the RK806 buck-2 regulator access needed to read and set that rail.
//!
//! # Board-confirmed ground truth (sources cited inline)
//!
//! - **SPI2 controller** = `spi@feb20000`, size `0x1000`, compatible
//!   `rockchip,rk3066-spi` (the standard Rockchip SPI IP). Register map and the
//!   bare-metal polling flow follow mainline `drivers/spi/spi-rockchip.c` and
//!   U-Boot `drivers/spi/rk_spi.c` (`rk_spi.h`).
//! - **RK806** = `rockchip,rk806`, CS 0, `spi-max-frequency = 1_000_000`, mode 0.
//!   SPI framing from the Orange Pi BSP `drivers/mfd/rk806-spi.c`
//!   (`rk806_spi_bus_read`/`rk806_spi_bus_write`) + constants in
//!   `include/linux/mfd/rk806.h`.
//! - **`vdd_cpu_lit_s0` = RK806 `dcdc-reg2` (buck #2)** — from
//!   `arch/arm64/boot/dts/rockchip/rk3588-rk806-single.dtsi`. Its running voltage
//!   selector is `RK806_BUCK2_ON_VSEL = 0x1B`, full-byte selector
//!   (`vsel_mask = 0xff`), encoded by `rk806_buck_voltage_ranges` in
//!   `drivers/regulator/rk806-regulator.c`:
//!   `V(uV) = 500000 + sel*6250` for `sel 0..=159` (500 mV..1500 mV, our whole
//!   CPU window). 675 mV = sel 28 (`0x1C`), 750 mV = sel 40 (`0x28`),
//!   800 mV = sel 48 (`0x30`).
//!
//! # Safety model
//!
//! [`init`] binds only after the RK806 identity and a plausible A55 rail
//! selector are read. [`set_uv_stepped_verified`] moves in either direction in
//! at most [`MAX_STEP_UV`] (25 mV) increments, rechecking identity and selector
//! after every write. A mismatch aborts and returns `false`.
//!
//! After U-Boot, SPI2 is left with its clocks gated **and** its controller held
//! in soft-reset, so [`init`] first **ungates `PCLK_SPI2` + `CLK_SPI2`**,
//! **de-asserts the SPI2 P+core soft-reset**, and **applies the full SPI2
//! `pinctrl-0`** (mux + pull + drive + schmitt, via the in-tree rockchip pinctrl
//! driver — a mux-only match is not enough; the pad config is what the RK806 link
//! needs, mirroring the i2c0 fix), then verifies the controller responds (a gated
//! APB reads all-zero, and a core still in reset transacts all-zero — either
//! would otherwise clock in a fabricated `0`); if it does not respond it stays
//! **unbound**. Every SPI poll loop is time-bounded
//! ([`SPI_TIMEOUT_NS`]) and treats an all-zero status register as a dead bus, so
//! a controller that dies after init makes [`get_uv`] return `None` rather than
//! hanging or fabricating a reading. `init`'s only SoC writes are to the SPI2
//! clock gate, soft-reset, and pin config; **no PMIC write** in `init`.
//!
//! # Integration (owned by the cpufreq probe, not wired here)
//!
//! This module performs **no** PMIC write on its own. Mirroring the A76 I2C
//! sibling, [`init`] maps the controller itself; the probe then reads/steps the
//! rail:
//!
//! ```ignore
//! use crate::soc::rockchip::cpufreq::pmic_spi;
//!
//! pmic_spi::init();                             // map, configure and validate
//! let boot_uv = pmic_spi::get_uv();             // read current A55 rail
//! pmic_spi::set_uv_stepped_verified(750_000);   // verified OPP voltage
//! ```

use core::{
    sync::atomic::{AtomicBool, Ordering},
    time::Duration,
};

// PMIC access is slow: an SPI register read/write busy-waits on the controller
// (up to 20 ms on failure). Serialisation must NOT disable preemption across that
// poll, or the caller would stall task-switching on its CPU for the whole
// transaction (the scheduling-starvation risk raised in review). So the slow
// transactions are guarded by a non-preempt-disabling bus-ownership flag
// (`BUS_BUSY` / [`BusGuard`]); the `RawSpinLock` below is used ONLY to
// store the controller handle (`init`) or clone it out (`BusGuard::claim`) — a
// microsecond window that never spans a poll. The runtime worker serializes
// normal DVFS requests, so `BusGuard::claim` bails on a contended diagnostic
// caller rather than spinning. `RawSpinLock` (not `SpinNoIrq`) keeps
// IRQs enabled; the lock is never taken from an interrupt handler.
use ax_sync::RawSpinLock;
use log::{info, warn};
use rdif_pinctrl::PinctrlDevice;

use crate::mmio::iomap;

// ---------------------------------------------------------------------------
// SPI2 controller (rockchip,rk3066-spi) — spi@feb20000
// ---------------------------------------------------------------------------

/// Physical base of the RK3588 SPI2 controller (`spi@feb20000`).
pub const RK3588_SPI2_BASE: usize = 0xfeb2_0000;
/// MMIO window size of the SPI2 controller.
pub const RK3588_SPI2_SIZE: usize = 0x1000;
/// Fallback SPI2 functional-clock rate for the baud divider, used only if
/// U-Boot left no usable divisor (see [`Rk806Spi::configure`]).
///
/// The OrangePi-5-Plus DT sets `assigned-clock-rates = <200000000>` for
/// `CLK_SPI2`; 200 MHz is also the RK3588 SPI source ceiling, so assuming it can
/// only *under*-shoot the target SCLK (safe: slower, still <= 1 MHz).
const RK3588_SPI2_FALLBACK_INPUT_HZ: u32 = 200_000_000;

/// Target serial clock for the RK806 (DT `spi-max-frequency = 1_000_000`).
const SPI_SCLK_HZ: u32 = 1_000_000;
/// RK806 chip-select index on SPI2.
const RK806_CS: u32 = 0;

// Register offsets (spi-rockchip.c ROCKCHIP_SPI_* / rk_spi.h struct layout).
const SPI_CTRLR0: usize = 0x0000;
const SPI_CTRLR1: usize = 0x0004;
const SPI_ENR: usize = 0x0008;
const SPI_SER: usize = 0x000c;
const SPI_BAUDR: usize = 0x0010;
const SPI_RXFTLR: usize = 0x0018;
const SPI_SR: usize = 0x0024;
const SPI_IMR: usize = 0x002c;
const SPI_ICR: usize = 0x0038;
const SPI_TXDR: usize = 0x0400;
const SPI_RXDR: usize = 0x0800;

// CTRLR0 fields (rk_spi.h). We now use the EXACT value Linux `spi-rockchip.c`
// programs on this board (read live: 0x2C01), since Linux reads the RK806 with
// it — master, 8-bit frame, mode 0, transmit+receive, EM_BIG.
const CR0_DFS_8BIT: u32 = 0x1; // [1:0] data frame size = 8 bit
const CR0_SSN_DELAY_ONE: u32 = 0x1 << 10; // one sclk CS-to-clk delay
const CR0_EM_BIG: u32 = 0x1 << 11; // endian: big (matches Linux spi-rockchip.c)
const CR0_HALF_WORD_OFF: u32 = 0x1 << 13; // APB 8-bit / SPI 8-bit access
// FRF_SPI (0<<16), TMOD_TR (0<<18), OMOD_MASTER (0<<20), FBM_MSB (0<<12),
// SCPH/SCPOL (mode 0 => 0<<6/0<<7), RXD sample delay 0 all contribute zero.
const SPI_CTRLR0_MODE0_8BIT: u32 =
    CR0_DFS_8BIT | CR0_SSN_DELAY_ONE | CR0_EM_BIG | CR0_HALF_WORD_OFF;

// Status register bits (rk_spi.h).
const SR_BUSY: u32 = 1 << 0;
const SR_TF_FULL: u32 = 1 << 1;
const SR_TF_EMPTY: u32 = 1 << 2;
const SR_RF_EMPT: u32 = 1 << 3;

// Linux's rk806-spi bus read is two transfers under one CS: three TX bytes
// followed by one RX byte. The controller must change direction between them.
const CR0_XFM_TO: u32 = 1 << 18;
const CR0_XFM_RO: u32 = 2 << 18;

const BAUDR_MIN: u32 = 2;
const BAUDR_MAX: u32 = 0xfffe;

// Main RK3588 CRU (write-masked clock/reset registers). U-Boot gates the SPI2
// clocks after using the RK806 at boot, so `init` must ungate them first — a
// gated APB reads all-zero, which the controller-alive check below rejects.
/// Main RK3588 CRU base.
const RK3588_CRU_BASE: usize = 0xfd7c_0000;
/// CRU window mapped for the ungate (only the first page is needed).
const RK3588_CRU_SIZE: usize = 0x1000;
/// `clkgate_con(14)` (`14*4 + 0x800`): holds the SPI2 gate bits.
const CRU_CLKGATE_CON14: usize = 0x838;
/// Write-masked ungate of `PCLK_SPI2` (bit 8) + `CLK_SPI2` (bit 13): high half
/// is the write-enable mask, low half is the value (0 == clock enabled on a
/// Rockchip CRU gate). == `0x2100_0000`.
const SPI2_CLK_UNGATE: u32 = ((1 << 8) | (1 << 13)) << 16;

/// Upper bound on any SPI poll loop. Generous vs. the ~40 us a 4-byte 1 MHz
/// frame takes; a dead SPI clock trips this instead of hanging.
const SPI_TIMEOUT_NS: u64 = 20_000_000; // 20 ms

// ---------------------------------------------------------------------------
// RK806 SPI framing (rk8xx-spi.c / rk808.h)
// ---------------------------------------------------------------------------

/// Command byte: write. `RK806_CMD_WRITE = BIT(7)`; CRC disabled (`= 0`); the
/// low nibble carries `value_bytes - 1`, which is 0 for our single-byte access.
const RK806_CMD_WRITE: u8 = 0x80;
/// Command byte: read. `RK806_CMD_READ = 0`; CRC disabled; low nibble 0.
const RK806_CMD_READ: u8 = 0x00;

/// RK806 buck-2 (`vdd_cpu_lit_s0`) running-voltage selector register.
const RK806_BUCK2_ON_VSEL: u8 = 0x1B;

/// RK806 chip-name / chip-version registers (`rk806-core.c`). They encode
/// `RK806` as name-high `0x80` and name-low high nibble `0x6`.
const RK806_CHIP_NAME: u8 = 0x5A;
const RK806_CHIP_VER: u8 = 0x5B;

// --- SPI2 controller soft-reset (RK3588 main CRU) -------------------------
// Board-observed (boot #2): after ungate the controller is clocked and its APB
// registers stick (`is_alive` passes), yet the serial transaction reads all-zero
// — the classic signature of the controller **core** held in soft-reset: the
// PCLK-domain reset is released (registers work) but the shift-engine reset is
// held, so nothing actually transacts. Same split the i2c0 sibling hit. SPI2's
// resets live in the MAIN CRU: SRST_P_SPI2 (PCLK) = bit 8 and SRST_SPI2 (core) =
// bit 13 of `softrst_con(14)`, from mainline `drivers/clk/rockchip/rst-rk3588.c`
// (`RK3588_CRU_RESET_OFFSET(SRST_P_SPI2,14,8)` / `(SRST_SPI2,14,13)`) — same bit
// layout as the clock gate. We de-assert both (0 == released); the core reset
// (bit 13) is the one that matches the symptom.
/// `softrst_con(14)` (`14*4 + 0xa00`): holds the SPI2 reset bits.
const CRU_SOFTRST_CON14: usize = 0xa38;
/// Write-masked de-assert of SRST_P_SPI2 (bit 8) + SRST_SPI2 (bit 13): high half
/// = write mask, low half = 0 (0 == reset released). Numerically equals the gate
/// ungate value (same bit positions) but targets a different register.
const SPI2_RST_DEASSERT: u32 = ((1 << 8) | (1 << 13)) << 16;
/// Settle after releasing the reset before touching the controller.
const RST_SETTLE_US: u64 = 20;

// RK3588 PMU1_IOC (@ 0xfd5f0000) GPIO0 A/B pad config, decoded from u-boot
// pinctrl-rk3588.c tables (verified against Linux's live values):
//   mux:   0x04 = GPIO0A_H (A4-7), 0x08 = GPIO0B_L (B0-3)  [4 bits/pin]
//   drive: 0x14 = GPIO0A_H,        0x18 = GPIO0B_L         [4 bits/pin]
//   pull:  0x20 = GPIO0A,          0x24 = GPIO0B           [2 bits/pin]
//   smt:   0x30 = GPIO0A,          0x34 = GPIO0B           [1 bit/pin]
// SPI2 pins: A5=CLK, A6=MOSI (in 0x04/0x14/0x20/0x30), B1=CS0, B3=MISO (in
// 0x08/0x18/0x24/0x34). The read-only dump below logs this whole region so it
// can be diffed against Linux's known-good reference to find the B3/MISO delta.
const RK3588_IOC_BASE: usize = 0xfd5f_0000;
const RK3588_IOC_SIZE: usize = 0x1000;

// ---------------------------------------------------------------------------
// RK806 buck voltage encoding (rk806_buck_voltage_ranges, range 1)
// ---------------------------------------------------------------------------

/// Range-1 base: selector 0 == 500 mV.
const RK806_VSEL_BASE_UV: u32 = 500_000;
/// Range-1 step: 6.25 mV per selector unit.
const RK806_VSEL_STEP_UV: u32 = 6_250;
/// Last selector of range 1 (== 1_493_750 uV; selector 160 is the range-2 base
/// at 1_500_000 uV). Linux's "500mV ~ 1500mV" range comment is approximate.
const RK806_VSEL_R1_MAX_SEL: u8 = 159;
/// Range-2 base (selector 160 == 1_500_000 uV), 25 mV step, up to selector 235.
const RK806_VSEL_R2_BASE_UV: u32 = 1_500_000;
const RK806_VSEL_R2_BASE_SEL: u8 = 160;
const RK806_VSEL_R2_STEP_UV: u32 = 25_000;
const RK806_VSEL_R2_MAX_SEL: u8 = 235;
/// Range-3: selector 236..=255 is a fixed 3_400_000 uV.
const RK806_VSEL_R3_UV: u32 = 3_400_000;

// ---------------------------------------------------------------------------
// Safety envelope for the A55 rail
// ---------------------------------------------------------------------------

/// Hard voltage floor for the A55 rail: the lowest Phase-1a OPP nominal
/// (1008 MHz -> 675 mV, standard SKU). Never set below this. Industrial J/M SKU
/// low OPPs sit at 750 mV; a boot read of ~750 is expected there and is fine.
pub const A55_MIN_UV: u32 = 675_000;
/// Maximum single-step magnitude for [`set_uv_stepped_verified`] (25 mV == 4 selectors).
pub const MAX_STEP_UV: u32 = 25_000;
/// Settle delay between stepped-lowering writes (>> the 25 mV ramp time at the
/// DT `regulator-ramp-delay = 12500` uV/us => ~2 us).
const STEP_SETTLE_US: u64 = 150;

// ---------------------------------------------------------------------------
// Controller handle + global state
// ---------------------------------------------------------------------------

/// A mapped, initialized SPI2 controller bound to the RK806.
#[derive(Clone)]
struct Rk806Spi {
    base: *mut u8,
}

// The controller handle is only ever stored/cloned under `PMIC` (a microsecond
// `RawSpinLock` window) and used while its owner holds `BUS_BUSY`; the MMIO
// mapping is stable for the kernel lifetime.
unsafe impl Send for Rk806Spi {}

/// Global RK806/SPI2 handle, populated once by [`init`]. The `RawSpinLock`
/// mutex is held only to store the handle or clone it out ([`BusGuard::claim`]),
/// never across an SPI poll.
static PMIC: RawSpinLock<Option<Rk806Spi>> = RawSpinLock::new(None);

/// Non-preempt-disabling bus-ownership flag for the slow RK806 SPI transactions
/// (`rk806_read`/`rk806_write` poll the controller, ~20 ms per transfer). Holding
/// it does not disable preemption, so a transfer can be preempted. The shared
/// runtime serializes DVFS requests; [`BusGuard::claim`] also rejects an
/// unexpected concurrent SPI caller instead of spinning.
static BUS_BUSY: AtomicBool = AtomicBool::new(false);

/// RAII ownership of the RK806 SPI bus for one transaction. Carries a clone of
/// the controller handle so the poll runs with no `RawSpinLock` guard held;
/// releases ownership on drop.
struct BusGuard {
    dev: Rk806Spi,
}

impl BusGuard {
    /// Take bus ownership without blocking, then clone the handle out under a
    /// microsecond `PMIC` lock. `None` if uninitialised or already owned.
    fn claim() -> Option<Self> {
        if BUS_BUSY
            .compare_exchange(false, true, Ordering::Acquire, Ordering::Relaxed)
            .is_err()
        {
            warn!("pmic_spi: bus already in use; skipping this transaction");
            return None;
        }
        let handle = PMIC.lock().as_ref().cloned();
        match handle {
            Some(dev) => Some(Self { dev }),
            None => {
                BUS_BUSY.store(false, Ordering::Release);
                None
            }
        }
    }
}

impl Drop for BusGuard {
    fn drop(&mut self) {
        BUS_BUSY.store(false, Ordering::Release);
    }
}

impl core::ops::Deref for BusGuard {
    type Target = Rk806Spi;
    fn deref(&self) -> &Rk806Spi {
        &self.dev
    }
}

impl Rk806Spi {
    #[inline]
    fn read(&self, off: usize) -> u32 {
        unsafe { self.base.add(off).cast::<u32>().read_volatile() }
    }

    #[inline]
    fn write(&self, off: usize, val: u32) {
        unsafe { self.base.add(off).cast::<u32>().write_volatile(val) }
    }

    /// One-time controller setup: master, mode 0, 8-bit frames, ~1 MHz SCLK.
    /// Idempotent; leaves the controller disabled (transfers enable per frame).
    ///
    /// U-Boot already drives the RK806 over SPI2 at boot, so its BAUDR is a
    /// proven-good ~1 MHz divisor — preserve it (like the I2C sibling preserves
    /// `CLKDIV`) and only compute one if the controller was left unconfigured.
    /// This removes any dependence on knowing the exact `CLK_SPI2` rate.
    fn configure(&self) {
        // Disable before touching CTRLR0/BAUDR (config is latched while idle).
        self.write(SPI_ENR, 0);
        self.write(SPI_SER, 0);

        let baud = self.read(SPI_BAUDR) & 0xffff;
        if (BAUDR_MIN..=BAUDR_MAX).contains(&baud) && (baud & 1) == 0 {
            info!("pmic_spi: SPI2 baud divisor preserved from U-Boot ({baud})");
        } else {
            let computed = baud_divider(RK3588_SPI2_FALLBACK_INPUT_HZ, SPI_SCLK_HZ);
            self.write(SPI_BAUDR, computed);
            info!("pmic_spi: SPI2 baud divisor computed {computed} (U-Boot left {baud:#x})");
        }

        self.write(SPI_CTRLR0, SPI_CTRLR0_MODE0_8BIT);
        // Mask + clear any interrupts; this is a poll-only master.
        self.write(SPI_IMR, 0);
        self.write(SPI_ICR, 0xffff_ffff);
    }

    /// Confirm the controller actually responds on its APB. `configure` always
    /// writes the fixed `SPI_CTRLR0_MODE0_8BIT`, so those bits reading back
    /// proves the bus is clocked and out of reset. A still-gated (or reset-held)
    /// controller reads 0 here, which fails the mask check — this is what closes
    /// the "gated APB looks like an empty-but-working bus" false-success hole.
    fn is_alive(&self) -> bool {
        self.read(SPI_CTRLR0) & SPI_CTRLR0_MODE0_8BIT == SPI_CTRLR0_MODE0_8BIT
    }

    /// Transmit one SPI phase while leaving chip select unchanged. The controller
    /// is disabled at both ends, allowing a receive-only phase under the same CS.
    fn send_phase(&self, tx: &[u8]) -> bool {
        self.write(SPI_ENR, 0);
        self.write(SPI_CTRLR0, SPI_CTRLR0_MODE0_8BIT | CR0_XFM_TO);
        self.write(SPI_CTRLR1, tx.len() as u32 - 1);
        self.write(SPI_ICR, 0xffff_ffff);
        self.write(SPI_ENR, 1);

        let deadline = now_ns().saturating_add(SPI_TIMEOUT_NS);
        for (index, byte) in tx.iter().enumerate() {
            loop {
                let sr = self.read(SPI_SR);
                if sr == 0 || now_ns() >= deadline {
                    warn!("pmic_spi: SPI2 TX phase stalled at {index}/{}", tx.len());
                    self.write(SPI_ENR, 0);
                    return false;
                }
                if sr & SR_TF_FULL == 0 {
                    self.write(SPI_TXDR, u32::from(*byte));
                    break;
                }
            }
        }
        loop {
            let sr = self.read(SPI_SR);
            if sr & (SR_TF_EMPTY | SR_BUSY) == SR_TF_EMPTY {
                self.write(SPI_ENR, 0);
                return true;
            }
            if sr == 0 || now_ns() >= deadline {
                warn!("pmic_spi: SPI2 TX phase did not finish");
                self.write(SPI_ENR, 0);
                return false;
            }
        }
    }

    /// Clock one receive-only byte after the command/address phase. In RO mode
    /// the controller generates SCLK from CTRLR1 without feeding TXDR.
    fn receive_phase(&self) -> Option<u8> {
        self.write(SPI_ENR, 0);
        self.write(SPI_CTRLR0, SPI_CTRLR0_MODE0_8BIT | CR0_XFM_RO);
        self.write(SPI_CTRLR1, 0);
        self.write(SPI_RXFTLR, 0);
        self.write(SPI_ICR, 0xffff_ffff);
        self.write(SPI_ENR, 1);

        let deadline = now_ns().saturating_add(SPI_TIMEOUT_NS);
        loop {
            let sr = self.read(SPI_SR);
            if sr == 0 || now_ns() >= deadline {
                warn!("pmic_spi: SPI2 RX phase stalled");
                self.write(SPI_ENR, 0);
                return None;
            }
            if sr & SR_RF_EMPT == 0 {
                let byte = self.read(SPI_RXDR) as u8;
                self.write(SPI_ENR, 0);
                return Some(byte);
            }
        }
    }

    /// Read one RK806 register with the BSP's two-transfer protocol: send
    /// `[READ, addr_lo, addr_hi]`, then receive one byte under the same CS.
    fn rk806_read(&self, reg: u8) -> Option<u8> {
        self.write(SPI_SER, 1 << RK806_CS);
        let result = self
            .send_phase(&[RK806_CMD_READ, reg, 0])
            .then(|| self.receive_phase())
            .flatten();
        self.write(SPI_SER, 0);
        result
    }

    /// Write one RK806 register. Frame: `[WRITE, addr_lo, addr_hi=0, value]`.
    /// Returns `false` on transfer timeout.
    #[must_use]
    fn rk806_write(&self, reg: u8, val: u8) -> bool {
        self.write(SPI_SER, 1 << RK806_CS);
        let result = self.send_phase(&[RK806_CMD_WRITE, reg, 0, val]);
        self.write(SPI_SER, 0);
        result
    }

    /// Read the A55 rail only when the same bus still identifies as an RK806.
    fn verified_buck2_selector(&self) -> Option<u8> {
        let name = self.rk806_read(RK806_CHIP_NAME)?;
        let version = self.rk806_read(RK806_CHIP_VER)?;
        let selector = self.rk806_read(RK806_BUCK2_ON_VSEL)?;
        valid_identity_and_selector(name, version, selector).then_some(selector)
    }
}

// ---------------------------------------------------------------------------
// Baud + voltage math (pure, unit-tested on the host)
// ---------------------------------------------------------------------------

/// SPI baud divider: even, in `[2, 0xfffe]`, rounded so the resulting SCLK is
/// `<= target_hz` (mirrors U-Boot `rkspi_set_clk`: `DIV_ROUND_UP` then round up
/// to the next even value).
fn baud_divider(input_hz: u32, target_hz: u32) -> u32 {
    let target = target_hz.max(1);
    let mut div = input_hz.div_ceil(target);
    div = div.clamp(BAUDR_MIN, BAUDR_MAX);
    // Round up to the next even number (hardware requires an even divisor);
    // rounding up only lowers the clock, which is the safe direction.
    div = (div + 1) & 0xfffe;
    div.clamp(BAUDR_MIN, BAUDR_MAX)
}

/// Decode an RK806 buck selector byte to microvolts (all three ranges).
fn vsel_to_uv(sel: u8) -> u32 {
    if sel <= RK806_VSEL_R1_MAX_SEL {
        RK806_VSEL_BASE_UV + u32::from(sel) * RK806_VSEL_STEP_UV
    } else if sel <= RK806_VSEL_R2_MAX_SEL {
        RK806_VSEL_R2_BASE_UV + u32::from(sel - RK806_VSEL_R2_BASE_SEL) * RK806_VSEL_R2_STEP_UV
    } else {
        RK806_VSEL_R3_UV
    }
}

/// Recognize an RK806 and an A55 rail selector within this board's OPP window.
/// A floating/looped-back MISO must never become a plausible voltage read.
fn valid_identity_and_selector(name: u8, version: u8, selector: u8) -> bool {
    name == 0x80
        && (version & 0xf0) == 0x60
        && (A55_MIN_UV..=950_000).contains(&vsel_to_uv(selector))
}

/// Encode microvolts to an RK806 buck selector byte, range 1 only (500 mV..
/// 1493.75 mV — spanning the entire CPU-rail window). Requires an **exact**
/// 6.25 mV-aligned value (like `pmic_i2c`'s encoder): returns `None` outside
/// range 1 or for any input that does not land exactly on a selector step, so
/// we never program an approximated voltage. Our OPP nominals (675/750/800 mV)
/// are all aligned.
fn uv_to_vsel(uv: u32) -> Option<u8> {
    let r1_max_uv = RK806_VSEL_BASE_UV + u32::from(RK806_VSEL_R1_MAX_SEL) * RK806_VSEL_STEP_UV;
    if uv < RK806_VSEL_BASE_UV || uv > r1_max_uv {
        return None;
    }
    let offset = uv - RK806_VSEL_BASE_UV;
    if !offset.is_multiple_of(RK806_VSEL_STEP_UV) {
        return None;
    }
    Some((offset / RK806_VSEL_STEP_UV) as u8)
}

// ---------------------------------------------------------------------------
// Time helpers
// ---------------------------------------------------------------------------

#[inline]
fn now_ns() -> u64 {
    axklib::time::monotonic_nanos()
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/// Ungate the SPI2 controller clocks (`PCLK_SPI2` + `CLK_SPI2`) in the main CRU.
///
/// Board-observed: U-Boot gates these after programming the RK806 at boot, so at
/// probe time the SPI2 APB is dead and reads all-zero — which without this looks
/// like a working-but-empty bus and yields a bogus `0` voltage. The Rockchip CRU
/// gate register is write-masked, so writing [`SPI2_CLK_UNGATE`] clears both gate
/// bits (0 == enabled). Returns `false` only if the CRU cannot be mapped.
fn ungate_spi2_clocks() -> bool {
    let cru = match iomap(RK3588_CRU_BASE, RK3588_CRU_SIZE) {
        Ok(v) => v,
        Err(err) => {
            warn!("pmic_spi: iomap CRU {RK3588_CRU_BASE:#x} failed: {err:?}");
            return false;
        }
    };
    // SAFETY: the CRU mapping covers `RK3588_CRU_SIZE` bytes and
    // `CRU_CLKGATE_CON14` (0x838) is within the first page. One write-masked
    // MMIO store; the gate register tolerates concurrent write-masked updates to
    // other bits, so no read-modify-write is needed.
    unsafe {
        cru.as_ptr()
            .add(CRU_CLKGATE_CON14)
            .cast::<u32>()
            .write_volatile(SPI2_CLK_UNGATE);
    }
    info!(
        "pmic_spi: ungated SPI2 PCLK+CLK (CRU {:#x} <= {SPI2_CLK_UNGATE:#010x})",
        RK3588_CRU_BASE + CRU_CLKGATE_CON14
    );
    true
}

/// Release the SPI2 controller from soft-reset in the main CRU so its shift
/// engine can transact. De-assert only (write masked zeros to SRST_P_SPI2 bit 8 +
/// SRST_SPI2 bit 13); we never assert, so nothing else is disturbed, and the
/// BAUDR/CTRLR0 that `configure` (re)writes afterwards take effect on a released
/// core. Idempotent (re-clearing an already-released reset is a no-op). Returns
/// `false` only if the CRU cannot be mapped.
fn deassert_spi2_reset() -> bool {
    let cru = match iomap(RK3588_CRU_BASE, RK3588_CRU_SIZE) {
        Ok(v) => v,
        Err(err) => {
            warn!("pmic_spi: iomap CRU {RK3588_CRU_BASE:#x} failed: {err:?}");
            return false;
        }
    };
    // SAFETY: the CRU mapping covers `RK3588_CRU_SIZE` bytes and
    // `CRU_SOFTRST_CON14` (0xa38) is within the first page. One write-masked MMIO
    // store clearing only the two SPI2 reset bits.
    unsafe {
        cru.as_ptr()
            .add(CRU_SOFTRST_CON14)
            .cast::<u32>()
            .write_volatile(SPI2_RST_DEASSERT);
    }
    axklib::time::busy_wait(Duration::from_micros(RST_SETTLE_US));
    info!(
        "pmic_spi: de-asserted SPI2 P+core reset (CRU {:#x} <= {SPI2_RST_DEASSERT:#010x})",
        RK3588_CRU_BASE + CRU_SOFTRST_CON14
    );
    true
}

/// Apply the FULL `spi@feb20000` pinctrl-0 (mux **+ pull + drive-strength +
/// schmitt**) via the registered Rockchip pinctrl driver — the same path that
/// fixed i2c0.
///
/// Board finding (boot #7): our previous mux-only check saw "already func1" yet
/// read AND write to the RK806 were both dead. i2c0 had the identical symptom and
/// was fixed by applying the *full* pin config, not just the mux — the DTS
/// pinconf flags (pull/drive/slew on `spi2m2_pins`/`spi2m2_cs0`) were u-boot's or
/// default, not what the RK806 link needs, so CLK/MOSI/CS never cleanly reached
/// the chip. Rather than hand-decode the pinconf, we apply the node's `pinctrl-0`
/// state through the in-tree pinctrl driver, which already encodes it. Pad-config
/// change only (no PMIC access); best-effort — any failure is logged and the
/// later transaction times out into a safe no-op.
fn set_spi2_pinmux() {
    let Some(pinctrl) = rdrive::get_one::<PinctrlDevice>() else {
        warn!("pmic_spi: PinctrlDevice not registered; cannot apply spi2 pinctrl");
        return;
    };
    let mut pinctrl = match pinctrl.lock() {
        Ok(guard) => guard,
        Err(err) => {
            warn!("pmic_spi: failed to lock PinctrlDevice: {err}; cannot apply spi2 pinctrl");
            return;
        }
    };
    let Some(fdt) = rdrive::with_fdt(Clone::clone) else {
        warn!("pmic_spi: live FDT not found; cannot apply spi2 pinctrl");
        return;
    };
    // Match the spi2 controller node by reg base (several SPI controllers share
    // the rk3066-spi compatible).
    let node = fdt
        .find_compatible(&["rockchip,rk3066-spi"])
        .into_iter()
        .find(|n| {
            n.regs()
                .into_iter()
                .next()
                .is_some_and(|r| r.address as usize == RK3588_SPI2_BASE)
        });
    let Some(node) = node else {
        warn!("pmic_spi: spi2 node @ {RK3588_SPI2_BASE:#x} not found in FDT; cannot apply pinctrl");
        return;
    };
    match pinctrl.apply_fdt_default_state(&fdt, node.as_node()) {
        Ok(()) => info!(
            "pmic_spi: applied spi2 pinctrl-0 (spi2m2 clk/mosi/miso/cs0 mux+pull+drive) via \
             rockchip pinctrl"
        ),
        Err(err) => warn!("pmic_spi: failed to apply spi2 pinctrl-0: {err:?}"),
    }

    // MISO loopback probe (last untested register): force GPIO0_B3 (= SPI2_MISO) to
    // INPUT direction. Linux leaves it input (GPIO0 DDR_L bit11 = 0); if StarryOS's
    // boot left B3 as a GPIO *output*, the pad would drive instead of sample, so the
    // controller reads its own TX shift register — exactly the observed rx==tx
    // loopback. The func-1 mux normally overrides GPIO direction, so this is a
    // long-shot, but it is the one register we have not yet forced. GPIO0 @ 0xfd8a0000,
    // SWPORT_DR_L=0x00, SWPORT_DDR_L=0x08 (write-masked: hi16 = per-bit mask).
    if let Ok(gpio0) = iomap(0xfd8a_0000, 0x100) {
        let p = gpio0.as_ptr();
        // SAFETY: GPIO0 mapping covers 0x100; DDR_L is at 0x08, within the page.
        let ddr = unsafe { p.add(0x08).cast::<u32>().read_volatile() };
        info!(
            "pmic_spi: GPIO0 DDR_L={:#010x} B3(bit11)={} (0=input) — forcing B3 input",
            ddr,
            (ddr >> 11) & 1
        );
        // Force B3 -> input: mask bit11 (hi16), value 0 (lo16).
        unsafe { p.add(0x08).cast::<u32>().write_volatile((1u32 << 11) << 16) };
    }
}

/// Read-only dump of the applied GPIO0 A/B pad config (boot #9 loopback debug).
/// Logs the whole PMU1_IOC first page for a direct line-by-line diff against
/// Linux's known-good reference, plus the decoded B3/MISO fields (mux 0x08[15:12],
/// drive 0x18[15:12], pull 0x24[7:6], smt 0x34[3]). Linux (works): B3 mux=1,
/// pull=3 (up), smt=0. Whichever field differs on our side is the loopback cause.
/// No writes.
fn dump_spi2_iomux() {
    let ioc = match iomap(RK3588_IOC_BASE, RK3588_IOC_SIZE) {
        Ok(v) => v.as_ptr(),
        Err(err) => {
            warn!("pmic_spi: iomap IOC {RK3588_IOC_BASE:#x} failed: {err:?}; skipping IOC dump");
            return;
        }
    };
    // SAFETY: the IOC mapping covers `RK3588_IOC_SIZE` bytes; every offset read
    // below is < 0x44, well within the first page. Read-only.
    let rd = |off: usize| unsafe { ioc.add(off).cast::<u32>().read_volatile() };
    let (mux_b, drv_b, pull_b, smt_b) = (rd(0x08), rd(0x18), rd(0x24), rd(0x34));
    info!(
        "pmic_spi: PMU1_IOC 00={:08x} 04={:08x} 08={:08x} 0c={:08x} 10={:08x} 14={:08x} 18={:08x} \
         1c={:08x} 20={:08x} 24={:08x} 28={:08x} 2c={:08x} 30={:08x} 34={:08x} 40={:08x}",
        rd(0x00),
        rd(0x04),
        rd(0x08),
        rd(0x0c),
        rd(0x10),
        rd(0x14),
        rd(0x18),
        rd(0x1c),
        rd(0x20),
        rd(0x24),
        rd(0x28),
        rd(0x2c),
        rd(0x30),
        rd(0x34),
        rd(0x40),
    );
    info!(
        "pmic_spi: B3/MISO decoded: mux={} (want 1) drive={} pull={} (want 3) smt={} (want 0)",
        (mux_b >> 12) & 0xf,
        (drv_b >> 12) & 0xf,
        (pull_b >> 6) & 0x3,
        (smt_b >> 3) & 0x1,
    );
}

/// Map and initialize the RK806-on-SPI2 controller. Idempotent; safe to call
/// from a `PostKernel` probe context (MMU up).
///
/// Ungates the SPI2 clocks (U-Boot gates them after talking to the RK806 at
/// boot), maps + configures the controller, then verifies it actually responds
/// on its APB. Returns `true` when the controller is bound and ready — including
/// an idempotent re-`init()` of an already-bound controller. Returns `false` on
/// a CRU/SPI2 MMIO mapping failure **or** if the controller does not respond
/// after ungate or the RK806 identity/rail selector cannot be verified.
/// In every `false` case the controller is left **unbound**, so
/// `get_uv`/`set_uv*` leave the boot voltage untouched.
pub fn init() -> bool {
    if PMIC.lock().is_some() {
        // Already bound: the controller is ready, so report success (not a
        // failure) and keep the existing binding.
        return true;
    }
    if !ungate_spi2_clocks() {
        return false;
    }
    let virt = match iomap(RK3588_SPI2_BASE, RK3588_SPI2_SIZE) {
        Ok(v) => v,
        Err(err) => {
            warn!("pmic_spi: iomap {RK3588_SPI2_BASE:#x} failed: {err:?}");
            return false;
        }
    };
    // SAFETY: `iomap` returned a mapping of `RK3588_SPI2_SIZE` bytes at the SPI2
    // controller base; `base` is only ever used for volatile MMIO within that
    // window, serialized through the `PMIC` mutex.
    let dev = Rk806Spi {
        base: virt.as_ptr(),
    };
    // Release the controller core from soft-reset (boot #2: is_alive passed but
    // the shift engine read all-zero — core reset held). Must precede configure()
    // so BAUDR/CTRLR0 land on a released core.
    if !deassert_spi2_reset() {
        return false;
    }
    // Apply the FULL spi2 pinctrl-0 (mux + pull + drive + schmitt) via the
    // rockchip pinctrl driver — boot #7 showed a mux-only match isn't enough; the
    // pad config is what fixed i2c0. Must precede any transfer.
    set_spi2_pinmux();
    // Boot #8: read confirmed MISO loopback. Dump the applied SPI2 mux so we can
    // check B3(MISO) is really func1 (vs A6/MOSI which works).
    dump_spi2_iomux();
    dev.configure();
    if !dev.is_alive() {
        warn!(
            "pmic_spi: SPI2 controller not responding after ungate (CTRLR0 read-back failed; APB \
             may still be gated or held in reset); leaving A55 rail untouched"
        );
        return false;
    }
    let (name, version, selector) = (
        dev.rk806_read(RK806_CHIP_NAME),
        dev.rk806_read(RK806_CHIP_VER),
        dev.rk806_read(RK806_BUCK2_ON_VSEL),
    );
    if !matches!((name, version, selector), (Some(n), Some(v), Some(s)) if valid_identity_and_selector(n, v, s))
    {
        warn!(
            "pmic_spi: RK806 identity/rail read-back failed (name={name:?}, version={version:?}, \
             buck2={selector:?}); leaving A55 rail unavailable"
        );
        return false;
    }
    info!("pmic_spi: RK806/SPI2 bound at {RK3588_SPI2_BASE:#x}, buck2={selector:?}");
    *PMIC.lock() = Some(dev);
    true
}

/// Read the current `vdd_cpu_lit` (A55 rail) voltage in microvolts, or `None`
/// if the controller is not initialized or the SPI read timed out.
pub fn get_uv() -> Option<u32> {
    let bus = BusGuard::claim()?;
    let sel = bus.verified_buck2_selector()?;
    let uv = vsel_to_uv(sel);
    info!("pmic_spi: A55 vdd_cpu_lit = {uv} uV (buck2 vsel {sel:#04x})");
    Some(uv)
}

/// Set the A55 rail to an OPP voltage in verified steps in either direction.
///
/// The RK806 chip identity and current buck-2 selector must be readable before
/// the first write. Each step is at most 25 mV and is followed by a fresh
/// identity plus selector read-back. A failed step aborts immediately, so the
/// caller must treat the rail as unknown and keep the clock at a safe setting.
pub fn set_uv_stepped_verified(target_uv: u32) -> bool {
    if !(A55_MIN_UV..=950_000).contains(&target_uv) {
        warn!("pmic_spi: target {target_uv} uV outside A55 OPP rail window");
        return false;
    }
    let Some(target_sel) = uv_to_vsel(target_uv) else {
        warn!("pmic_spi: target {target_uv} uV is not an RK806 selector voltage");
        return false;
    };
    let Some(bus) = BusGuard::claim() else {
        warn!("pmic_spi: set_uv_stepped_verified before init or busy");
        return false;
    };
    let dev = &*bus;
    let Some(mut current_sel) = dev.verified_buck2_selector() else {
        warn!("pmic_spi: RK806 identity/rail read failed before voltage change");
        return false;
    };
    let step_sel = (MAX_STEP_UV / RK806_VSEL_STEP_UV).max(1) as u8;
    while current_sel != target_sel {
        let next = if current_sel < target_sel {
            target_sel.min(current_sel.saturating_add(step_sel))
        } else {
            target_sel.max(current_sel.saturating_sub(step_sel))
        };
        if !write_and_verify(dev, next) {
            return false;
        }
        axklib::time::busy_wait(Duration::from_micros(STEP_SETTLE_US));
        current_sel = next;
    }
    info!("pmic_spi: A55 vdd stepped to {target_uv} uV (vsel {target_sel:#04x})");
    true
}

/// Write buck-2 `ON_VSEL` and confirm the read-back selector matches.
fn write_and_verify(dev: &Rk806Spi, sel: u8) -> bool {
    if !dev.rk806_write(RK806_BUCK2_ON_VSEL, sel) {
        warn!("pmic_spi: buck2 vsel write timed out (sel {sel:#04x})");
        return false;
    }
    match dev.verified_buck2_selector() {
        Some(rb) if rb == sel => true,
        Some(rb) => {
            warn!("pmic_spi: buck2 vsel read-back {rb:#04x} != written {sel:#04x}; aborting");
            false
        }
        None => {
            warn!("pmic_spi: buck2 vsel read-back failed after write; aborting");
            false
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn vsel_decodes_known_opp_nominals() {
        assert_eq!(vsel_to_uv(0x1c), 675_000); // sel 28
        assert_eq!(vsel_to_uv(0x28), 750_000); // sel 40
        assert_eq!(vsel_to_uv(0x30), 800_000); // sel 48
        assert_eq!(vsel_to_uv(0), 500_000);
        // Selector 159 (range-1 max) is 1_493_750 uV; 1_500_000 is selector 160.
        assert_eq!(vsel_to_uv(RK806_VSEL_R1_MAX_SEL), 1_493_750);
    }

    #[test]
    fn rk806_identity_and_rail_gate_rejects_loopback() {
        assert!(valid_identity_and_selector(0x80, 0x62, 0x30));
        assert!(!valid_identity_and_selector(0, 0, 0));
        assert!(!valid_identity_and_selector(0x5a, 0x5b, 0x1b));
        assert!(!valid_identity_and_selector(0x80, 0x62, 0));
        assert!(!valid_identity_and_selector(0x80, 0x62, 0xff));
    }

    #[test]
    fn vsel_decodes_upper_ranges() {
        assert_eq!(vsel_to_uv(160), 1_500_000); // range 2 base
        assert_eq!(vsel_to_uv(161), 1_525_000);
        assert_eq!(vsel_to_uv(235), 3_375_000);
        assert_eq!(vsel_to_uv(236), 3_400_000); // range 3 fixed
        assert_eq!(vsel_to_uv(255), 3_400_000);
    }

    #[test]
    fn uv_encodes_opp_nominals_exactly() {
        assert_eq!(uv_to_vsel(675_000), Some(0x1c));
        assert_eq!(uv_to_vsel(750_000), Some(0x28));
        assert_eq!(uv_to_vsel(800_000), Some(0x30));
    }

    #[test]
    fn uv_encode_roundtrips_within_range1() {
        for sel in 0..=RK806_VSEL_R1_MAX_SEL {
            let uv = vsel_to_uv(sel);
            assert_eq!(uv_to_vsel(uv), Some(sel), "sel {sel}");
        }
    }

    #[test]
    fn uv_encode_rejects_out_of_range1() {
        assert_eq!(uv_to_vsel(499_000), None);
        assert_eq!(uv_to_vsel(1_600_000), None);
    }

    #[test]
    fn uv_encode_rejects_unaligned_steps() {
        // In-range but not on a 6.25 mV boundary: reject rather than approximate.
        assert_eq!(uv_to_vsel(675_000 + 1), None);
        assert_eq!(uv_to_vsel(676_000), None); // 176_000 % 6250 != 0
        assert_eq!(uv_to_vsel(500_001), None);
        // Boundaries stay accepted.
        assert_eq!(uv_to_vsel(500_000), Some(0));
        assert_eq!(uv_to_vsel(506_250), Some(1));
    }

    #[test]
    fn baud_divider_even_and_under_target() {
        // 200 MHz functional clock, 1 MHz target -> even divisor, sclk <= 1 MHz.
        let div = baud_divider(200_000_000, 1_000_000);
        assert_eq!(div % 2, 0);
        assert!(200_000_000 / div <= 1_000_000, "div {div}");
        assert_eq!(div, 200);
    }

    #[test]
    fn baud_divider_clamps_and_stays_even() {
        assert_eq!(baud_divider(1_000_000, 1_000_000) % 2, 0);
        assert!(baud_divider(u32::MAX, 1) <= BAUDR_MAX);
        assert!(baud_divider(1, 1_000_000) >= BAUDR_MIN);
    }

    #[test]
    fn step_size_is_four_selectors() {
        assert_eq!(MAX_STEP_UV / RK806_VSEL_STEP_UV, 4); // 25 mV / 6.25 mV
    }

    #[test]
    fn spi2_ungate_value_matches_gate_bits() {
        // clkgate_con(14): PCLK_SPI2 = bit 8, CLK_SPI2 = bit 13. Write-masked:
        // high half selects the bits, low half writes 0 to enable them.
        assert_eq!(SPI2_CLK_UNGATE, 0x2100_0000);
        assert_eq!(SPI2_CLK_UNGATE & 0xffff, 0); // low half all-0 => enable
        assert_eq!(SPI2_CLK_UNGATE >> 16, (1 << 8) | (1 << 13));
        assert_eq!(CRU_CLKGATE_CON14, 14 * 4 + 0x800); // 0x838
    }

    #[test]
    fn ctrlr0_mode0_8bit_value() {
        // Linux spi-rockchip.c live value on this board: master, mode 0, 8-bit
        // DFS, one-cycle CS delay, EM_BIG, APB 8-bit access.
        assert_eq!(SPI_CTRLR0_MODE0_8BIT, 0x2c01);
    }

    #[test]
    fn spi2_reset_deassert_matches_reset_bits() {
        // softrst_con(14): SRST_P_SPI2 = bit 8, SRST_SPI2 = bit 13. Write-masked
        // de-assert: high half selects the bits, low half writes 0 to release.
        assert_eq!(SPI2_RST_DEASSERT, 0x2100_0000);
        assert_eq!(SPI2_RST_DEASSERT & 0xffff, 0); // low half all-0 => released
        assert_eq!(SPI2_RST_DEASSERT >> 16, (1 << 8) | (1 << 13));
        assert_eq!(CRU_SOFTRST_CON14, 14 * 4 + 0xa00); // 0xa38
    }
}
