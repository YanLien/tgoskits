//! Host task type facade for AxVM's ArceOS-backed runtime.

use super::arceos;

pub(crate) type ThreadHandle = arceos::ArceOsThreadHandle;
pub(crate) type ThreadWakeHandle = arceos::ArceOsThreadWakeHandle;
pub(crate) type IrqNotification = arceos::ArceOsIrqNotification;
pub(crate) type WaitQueueHandle = arceos::ArceOsWaitQueueHandle;
pub(crate) use arceos::{
    ArceOsCpuSet as CpuSet, ArceOsSchedulePolicy as SchedulePolicy,
    ArceOsSwitchReason as SwitchReason, ArceOsThreadExtension as ThreadExtension,
    ArceOsThreadExtensionOps as ThreadExtensionOps, ArceOsThreadId as ThreadId,
};

pub(crate) fn current_thread() -> ThreadHandle {
    arceos::current_thread()
}

pub(crate) use ax_std::os::arceos::{task::thread::StagedThread, thread::builder};

pub(crate) fn yield_now() {
    arceos::yield_now();
}

pub(crate) fn cpu_set_from_raw_bits(bits: usize) -> CpuSet {
    arceos::cpu_set_from_raw_bits(bits)
}

pub(crate) fn current_cpu_id() -> usize {
    arceos::current_cpu_id()
}

pub(crate) fn run_on_cpu_sync(
    cpu_id: usize,
    operation: unsafe fn(*mut ()),
    argument: *mut (),
) -> Result<(), arceos::ArceOsIrqError> {
    arceos::run_on_cpu_sync(cpu_id, operation, argument)
}

pub(crate) fn wait_queue_wait_until(queue: &WaitQueueHandle, condition: impl Fn() -> bool) {
    arceos::wait_queue_wait_until(queue, condition);
}

pub(crate) fn wait_queue_wake(queue: &WaitQueueHandle, count: u32) {
    arceos::wait_queue_wake(queue, count);
}

pub(crate) fn send_ipi(cpu_id: usize) {
    arceos::send_ipi(cpu_id);
}
