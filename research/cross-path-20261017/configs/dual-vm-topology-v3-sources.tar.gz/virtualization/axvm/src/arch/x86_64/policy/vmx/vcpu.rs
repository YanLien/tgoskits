// Copyright 2025 The Axvisor Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use core::{
    fmt::{Debug, Formatter, Result},
    mem::size_of,
};
use std::{collections::VecDeque, vec::Vec};

use ax_cpu::registers::Msr;
use bit_field::BitField;
use raw_cpuid::CpuId;
use x86_64::registers::{
    control::{Cr0Flags, Cr4Flags, EferFlags},
    rflags::RFlags,
};
use x86_vlapic::EmulatedLocalApic;

use super::{VmxExitInfo, vmcs::*, *};
use crate::arch::x86_64::policy::{
    pending_event::{
        PendingEvent, PendingEventKind, PendingEventSource, is_valid_fixed_apic_vector,
        needs_interrupt_window, queue_pending_event, select_pending_event,
    },
    port_io::*,
    types::UNRESOLVED_NEXT_RIP,
    *,
};

const VMX_PREEMPTION_TIMER_SET_VALUE: u32 = 100_000;

const QEMU_EXIT_PORT: u16 = 0x604;
const X86_PIT_PORT_BASE: u16 = 0x40;
const X86_PIT_PORT_COUNT: u32 = 4;
const X86_PIT_SPEAKER_PORT: u16 = 0x61;
const X2APIC_MSR_BASE: u32 = 0x800;
const X2APIC_MSR_END: u32 = 0x8ff;
const X2APIC_EOI_MSR: u32 = X2APIC_MSR_BASE + 0xb;
const X86_LOCAL_APIC_EOI_OFFSET: usize = 0xb0;
const X86_IOAPIC_BASE: usize = 0xfec0_0000;
const X86_IOAPIC_SIZE: usize = 0x1000;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct VmxInjectionEvent {
    event: PendingEvent,
    int_type: VmxInterruptionType,
    instruction_len: Option<u32>,
}

impl VmxInjectionEvent {
    fn pending(event: PendingEvent) -> Self {
        Self {
            event,
            int_type: vmcs::interruption_type_for_event(event),
            instruction_len: None,
        }
    }
}

fn interrupted_vmx_event(
    info: VmxInterruptInfo,
    exit_instruction_len: u32,
    injected: Option<VmxInjectionEvent>,
) -> Option<VmxInjectionEvent> {
    if !info.valid {
        return None;
    }

    let matched = injected
        .filter(|event| event.event.vector == info.vector && event.int_type == info.int_type);
    let level_triggered = matched.is_some_and(|event| event.event.level_triggered);
    let kind = if info.int_type == VmxInterruptionType::External {
        let source = matched.map_or(PendingEventSource::FixedApic, |event| {
            match event.event.kind {
                PendingEventKind::ExternalInterrupt(source) => source,
                PendingEventKind::Exception => PendingEventSource::FixedApic,
            }
        });
        PendingEventKind::ExternalInterrupt(source)
    } else {
        PendingEventKind::Exception
    };
    let event = match kind {
        PendingEventKind::ExternalInterrupt(source) => {
            PendingEvent::external_interrupt(info.vector, level_triggered, source)
        }
        PendingEventKind::Exception => PendingEvent::exception(
            info.vector,
            (info.int_type == VmxInterruptionType::HardException)
                .then_some(info.err_code)
                .flatten(),
        ),
    };
    Some(VmxInjectionEvent {
        event,
        int_type: info.int_type,
        instruction_len: info.int_type.is_soft().then_some(exit_instruction_len),
    })
}

use ax_cpu::virtualization::ExecutionMode as VmCpuMode;

fn secondary_control_bits_allowed(bits: u32) -> bool {
    // SAFETY: this helper is used by the VMX setup owner on its bound CPU.
    unsafe { ax_cpu::virtualization::VmxControl::Secondary.capabilities() }
        .is_ok_and(|capability| capability.allows(bits))
}

fn supported_apic_virtualization_controls(
    allowed: impl Fn(u32) -> bool,
) -> vmcs::controls::SecondaryControls {
    use vmcs::controls::SecondaryControls;

    let mut controls = SecondaryControls::empty();
    if allowed(SecondaryControls::VIRTUALIZE_APIC.bits()) {
        controls |= SecondaryControls::VIRTUALIZE_APIC;
    }
    // This backend injects interrupts through VM-entry fields and maintains
    // the software vLAPIC ISR itself. Virtual-interrupt delivery would require
    // keeping VMCS GUEST_INTR_STATUS (RVI/SVI) synchronized like KVM's APICv
    // path; enabling it without that state machine mixes two IRQ owners.
    controls
}

/// A virtual CPU within a guest.
pub struct VmxVcpu<H: X86HostOps, M: ControlMemory> {
    /// Complete CPU hardware state; software emulation stays in this owner.
    cpu: ax_cpu::virtualization::Vcpu<M>,
    /// The guest entry point.
    entry: Option<X86GuestPhysAddr>,
    /// The EPT root address.
    nested_page_table_root: Option<X86HostPhysAddr>,
    translation_root_dirty: bool,
    /// Resolved device MMIO ranges decoded as emulated MMIO exits.
    intercepted_mmio: Vec<X86InterceptedMmioRange>,
    // /// Whether this VCPU is a host VCpu. Used in type 1.5 hypervisor.
    // is_host: bool, temporary removed because we don't care about type 1.5 now
    setup_ready: bool,
    configured: bool,

    // Interrupt-related fields
    /// Pending events to be injected to the guest.
    pending_events: VecDeque<PendingEvent>,
    /// Event written for the current VM-entry attempt.
    injecting_event: Option<VmxInjectionEvent>,
    /// Event whose delivery was interrupted by the previous VM exit.
    reinjection_event: Option<VmxInjectionEvent>,
    /// Emulated Local APIC.
    vlapic: EmulatedLocalApic<H>,
    /// Guest RAM regions used to read guest instructions and page tables.
    guest_memory_regions: Vec<X86GuestMemoryRegion>,
}

impl<H: X86HostOps, M: ControlMemory> VmxVcpu<H, M> {
    /// Create a new [`VmxVcpu`].
    pub fn new(
        vm_id: usize,
        vcpu_id: usize,
        memory: ax_cpu::virtualization::VmxControlMemory<M>,
        xstate: GuestXstate<M>,
        config: X86VcpuCreateConfig<H::Runtime>,
    ) -> X86VcpuResult<Self> {
        // SAFETY: this backend is constructed by the initialized ring-0 VMX
        // host, before binding any of these newly allocated control leases.
        let mut cpu =
            unsafe { ax_cpu::virtualization::Vcpu::new(VcpuControlMemory::Vmx(memory), xstate)? };
        cpu.vmx_controls_mut()
            .expect("VMX policy CPU")
            .intercept_all_msrs(false);
        let vcpu = Self {
            cpu,
            entry: None,
            nested_page_table_root: None,
            translation_root_dirty: true,
            intercepted_mmio: Vec::new(),
            setup_ready: false,
            configured: false,
            pending_events: VecDeque::with_capacity(8),
            injecting_event: None,
            reinjection_event: None,
            vlapic: EmulatedLocalApic::<H>::new(config.runtime, vm_id, vcpu_id),
            guest_memory_regions: Vec::new(),
        };
        info!(
            "[HV] created VmxVcpu(vmcs: {:#x})",
            vcpu.cpu
                .vmx_controls()
                .expect("VMX policy CPU")
                .vmcs()
                .physical_address()
        );
        Ok(vcpu)
    }

    // /// Get the identifier of this [`VmxVcpu`].
    // pub fn vcpu_id(&self) -> usize {
    //     get_current_vcpu::<Self>().unwrap().id()
    // }

    /// Bind this [`VmxVcpu`] to current logical processor.
    pub fn bind_to_current_processor(&mut self) -> X86VcpuResult {
        if !self.setup_ready {
            return Err(X86VcpuError::BadState);
        }
        // SAFETY: AxVM retains the binding CPU and masks IRQs for this transition.
        unsafe {
            self.cpu.bind()?;
        }
        let result = (|| {
            if !self.configured {
                self.setup_vmcs_guest(self.entry.ok_or(X86VcpuError::BadState)?)?;
                self.setup_vmcs_control(
                    self.nested_page_table_root.ok_or(X86VcpuError::BadState)?,
                    true,
                )?;
                self.configured = true;
            } else if self.translation_root_dirty {
                vmcs::set_ept_pointer(
                    self.cpu.vmx_controls_mut().expect("VMX policy CPU"),
                    self.nested_page_table_root.ok_or(X86VcpuError::BadState)?,
                )?;
            }
            self.translation_root_dirty = false;
            Ok(())
        })();
        if result.is_err() {
            // SAFETY: initialization has not entered a guest and still owns
            // the IRQ-excluded CPU. A failed retirement cannot return the
            // still-current VMCS to a different owner or release the CPU pin.
            if unsafe { self.cpu.unbind() }.is_err() {
                std::process::abort();
            }
        }
        result
    }

    /// Unbinds the stopped VMCS and resets its hardware launch state.
    pub fn unbind_from_current_processor(&mut self) -> X86VcpuResult {
        // SAFETY: AxVM owns the pinned, IRQ-excluded binding teardown.
        unsafe {
            self.cpu.unbind()?;
        }
        Ok(())
    }

    /// Get CPU mode of the guest.
    pub fn get_cpu_mode(&self) -> VmCpuMode {
        self.cpu.execution_mode().expect("bound guest mode")
    }

    /// Run the guest. It returns when a vm-exit happens and returns the vm-exit if it cannot be handled by this [`VmxVcpu`] itself.
    fn inner_run(&mut self) -> X86VcpuResult<Option<VmxExitInfo>> {
        self.inject_pending_events()?;

        // SAFETY: the runtime owns the pinned, IRQ-excluded CPU and guest
        // mappings. CPU code restores every host bank before returning here.
        let exit_info = match unsafe { self.cpu.run()? } {
            ax_cpu::virtualization::Exit::Vmx(exit) => exit,
            ax_cpu::virtualization::Exit::Svm(_) => unreachable!("VMX policy CPU"),
        };

        if !exit_info.entry_failure {
            self.complete_event_injection(&exit_info)?;
        }
        // debug!("VM exit: {:#x?}", exit_info);

        match self.builtin_vmexit_handler(&exit_info) {
            Some(result) => match result {
                Ok(()) => Ok(None),
                Err(err) => {
                    panic!(
                        "VmxVcpu failed to handle a VM-exit that should be handled by itself: \
                         {:?}, error {:?}, vcpu: {:#x?}",
                        exit_info.exit_reason, err, self
                    );
                }
            },
            None => Ok(Some(exit_info)),
        }
    }

    /// Information for VM exits due to I/O instructions.
    pub fn io_exit_info(&self) -> X86VcpuResult<vmcs::VmxIoExitInfo> {
        self.cpu
            .vmx_controls()
            .expect("VMX policy CPU")
            .io_exit_info()
            .map_err(X86VcpuError::from)
    }

    /// Information for VM exits due to nested page table faults (EPT violation).
    pub fn nested_page_fault_info(&self) -> X86VcpuResult<X86NestedPageFaultInfo> {
        vmcs::ept_violation_info(self.cpu.vmx_controls().expect("VMX policy CPU"))
    }

    /// Information for VM exits due to APIC access.
    pub fn apic_access_exit_info(&self) -> X86VcpuResult<vmcs::ApicAccessExitInfo> {
        vmcs::apic_access_exit_info(self.cpu.vmx_controls().expect("VMX policy CPU"))
    }

    /// Guest general-purpose registers.
    pub fn regs(&self) -> &GeneralRegisters {
        self.cpu.registers()
    }

    /// Mutable reference of guest general-purpose registers.
    pub fn regs_mut(&mut self) -> &mut GeneralRegisters {
        self.cpu.registers_mut()
    }

    /// Guest stack pointer. (`RSP`)
    pub fn stack_pointer(&self) -> usize {
        self.cpu
            .vmx_controls()
            .expect("VMX policy CPU")
            .read(VmcsGuestNW::RSP)
            .map_err(X86VcpuError::from)
            .unwrap()
    }

    /// Translate guest virtual addr to linear addr    
    pub fn gla2gva(&self, guest_rip: X86GuestVirtAddr) -> X86GuestVirtAddr {
        let cpu_mode = self.get_cpu_mode();
        let seg_base = if cpu_mode == VmCpuMode::Mode64 {
            0
        } else {
            self.cpu
                .vmx_controls()
                .expect("VMX policy CPU")
                .read(VmcsGuestNW::CS_BASE)
                .map_err(X86VcpuError::from)
                .unwrap()
        };
        // debug!(
        //     "seg_base: {:#x}, guest_rip: {:#x} cpu mode:{:?}",
        //     seg_base, guest_rip, cpu_mode
        // );
        guest_rip + seg_base
    }

    /// Advance guest `RIP` by `instr_len` bytes.
    pub fn advance_rip(&mut self, instr_len: u8) -> X86VcpuResult {
        let controls = self.cpu.vmx_controls_mut().expect("VMX policy CPU");
        let rip = controls.read(VmcsGuestNW::RIP)?;
        controls.write(VmcsGuestNW::RIP, rip + usize::from(instr_len))?;
        Ok(())
    }

    /// Install an absolute guest `RIP`.
    ///
    /// Used when a device-serviced PIO/MMIO access retires on the next bound
    /// entry; the value was computed while the instruction was still current.
    pub fn set_rip(&mut self, rip: u64) -> X86VcpuResult {
        let address = usize::try_from(rip).map_err(|_| X86VcpuError::InvalidData)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsGuestNW::RIP, address)?;
        Ok(())
    }

    /// Retirement `RIP` for a decoded access of `instruction_len` bytes.
    fn next_rip_after(&self, instruction_len: u8) -> X86VcpuResult<u64> {
        let rip = self
            .cpu
            .vmx_controls()
            .expect("VMX policy CPU")
            .read(VmcsGuestNW::RIP)?;
        Ok((rip as u64).wrapping_add(u64::from(instruction_len)))
    }

    /// Retires one decoded port-I/O or MMIO access.
    ///
    /// The in-core APIC fast paths already performed the access (and answer
    /// [`X86VmExit::Nothing`]); they advance `RIP` here because no device
    /// completion exists. Every device-serviced exit instead carries the
    /// retirement `RIP` so the task layer installs it only after the device
    /// service succeeded, which keeps the nested-fault retry at the same PC.
    fn retire_decoded_access(
        &mut self,
        exit: X86VmExit,
        instruction_len: u8,
    ) -> X86VcpuResult<X86VmExit> {
        match exit {
            X86VmExit::Nothing => {
                self.advance_rip(instruction_len)?;
                Ok(X86VmExit::Nothing)
            }
            X86VmExit::InterruptEnd { vector } => {
                // The local-APIC EOI write was fully emulated in-core, so it
                // retires immediately while still carrying the vector the task
                // layer needs for IOAPIC EOI propagation.
                self.advance_rip(instruction_len)?;
                Ok(X86VmExit::InterruptEnd { vector })
            }
            exit => {
                let next_rip = self.next_rip_after(instruction_len)?;
                Ok(exit.with_next_rip(next_rip))
            }
        }
    }

    fn queue_event(&mut self, event: PendingEvent) {
        queue_pending_event(&mut self.pending_events, event);
    }

    fn queue_fixed_apic_interrupt(&mut self, vector: u8, level_triggered: bool) -> X86VcpuResult {
        if !is_valid_fixed_apic_vector(vector) {
            return x86_err!(InvalidInput, "fixed APIC vector must be in 32..=255");
        }
        self.queue_event(PendingEvent::external_interrupt(
            vector,
            level_triggered,
            PendingEventSource::FixedApic,
        ));
        Ok(())
    }

    /// If enable, a VM exit occurs at the beginning of any instruction if
    /// `RFLAGS.IF` = 1 and there are no other blocking of interrupts.
    /// (see SDM, Vol. 3C, Section 24.4.2)
    pub fn set_interrupt_window(&mut self, enable: bool) -> X86VcpuResult {
        let mut ctrl = self
            .cpu
            .vmx_controls()
            .expect("VMX policy CPU")
            .read(VmcsControl32::PRIMARY_PROCBASED_EXEC_CONTROLS)
            .map_err(X86VcpuError::from)?;
        let bits = vmcs::controls::PrimaryControls::INTERRUPT_WINDOW_EXITING.bits();
        if enable {
            ctrl |= bits
        } else {
            ctrl &= !bits
        }
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsControl32::PRIMARY_PROCBASED_EXEC_CONTROLS, ctrl)
            .map_err(X86VcpuError::from)?;
        Ok(())
    }
}

// Implementation of private methods
impl<H: X86HostOps, M: ControlMemory> VmxVcpu<H, M> {
    fn setup_io_bitmap(&mut self, config: X86VcpuSetupConfig) -> X86VcpuResult {
        // By default, I/O bitmap is set as `intercept_all`.
        // Todo: these should be combined with emulated pio device management,
        // in `modules/axvm/src/device/x86_64/mod.rs` somehow.
        let io_to_be_intercepted = QEMU_EXIT_PORT..QEMU_EXIT_PORT + 1; // QEMU exit port.
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .set_io_range(
                io_to_be_intercepted.start as _,
                io_to_be_intercepted.count() as u32,
                true,
            )?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .set_io_range(X86_PIT_PORT_BASE, X86_PIT_PORT_COUNT, true)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .set_io_intercept(X86_PIT_SPEAKER_PORT, true);
        for range in config.intercepted_port_ranges() {
            self.cpu
                .vmx_controls_mut()
                .expect("VMX policy CPU")
                .set_io_range(range.base, range.length as u32, true)?;
        }
        Ok(())
    }

    #[allow(dead_code)]
    fn setup_msr_bitmap(&mut self) -> X86VcpuResult {
        // Intercept IA32_APIC_BASE MSR accesses
        const IA32_APIC_BASE: u32 = 0x1b;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .set_msr_read_intercept(IA32_APIC_BASE, true)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .set_msr_write_intercept(IA32_APIC_BASE, true)?;

        // This is strange, guest Linux's access to `IA32_UMWAIT_CONTROL` will cause an exception.
        // But if we intercept it, it seems okay.
        const IA32_UMWAIT_CONTROL: u32 = 0xe1;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .set_msr_write_intercept(IA32_UMWAIT_CONTROL, true)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .set_msr_read_intercept(IA32_UMWAIT_CONTROL, true)?;

        // Intercept all x2APIC MSR accesses
        for msr in 0x800..=0x83f {
            self.cpu
                .vmx_controls_mut()
                .expect("VMX policy CPU")
                .set_msr_read_intercept(msr, true)?;
            self.cpu
                .vmx_controls_mut()
                .expect("VMX policy CPU")
                .set_msr_write_intercept(msr, true)?;
        }
        Ok(())
    }

    fn prepare_vmcs(&mut self, config: X86VcpuSetupConfig) -> X86VcpuResult {
        if self
            .cpu
            .vmx_controls()
            .expect("VMX policy CPU")
            .vmcs()
            .is_bound()
        {
            return Err(X86VcpuError::BadState);
        }
        self.guest_memory_regions = config.guest_memory_regions.clone();
        self.intercepted_mmio = config.intercepted_mmio.clone();
        self.setup_io_bitmap(config)?;
        self.setup_msr_bitmap()?;
        self.configured = false;
        self.setup_ready = true;
        Ok(())
    }

    fn setup_vmcs_guest(&mut self, entry: X86GuestPhysAddr) -> X86VcpuResult {
        let entry_state = x86_real_mode_entry_state(entry);
        let cr0_val: Cr0Flags =
            Cr0Flags::NOT_WRITE_THROUGH | Cr0Flags::CACHE_DISABLE | Cr0Flags::EXTENSION_TYPE;
        self.set_cr(0, cr0_val.bits());
        self.set_cr(4, 0);

        macro_rules! set_guest_segment {
            ($seg:ident, $access_rights:expr) => {{
                paste::paste! {
                    self.cpu.vmx_controls_mut().expect("VMX policy CPU").write(VmcsGuest16::[<$seg _SELECTOR>], 0)?;
                    self.cpu.vmx_controls_mut().expect("VMX policy CPU").write(VmcsGuestNW::[<$seg _BASE>], 0)?;
                    self.cpu.vmx_controls_mut().expect("VMX policy CPU").write(VmcsGuest32::[<$seg _LIMIT>], 0xffff)?;
                    self.cpu.vmx_controls_mut().expect("VMX policy CPU").write(VmcsGuest32::[<$seg _ACCESS_RIGHTS>], $access_rights)?;
                }
            }};
        }

        set_guest_segment!(ES, 0x93); // 16-bit, present, data, read/write, accessed
        set_guest_segment!(CS, 0x9b); // 16-bit, present, code, exec/read, accessed
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsGuest16::CS_SELECTOR, entry_state.cs_selector)
            .map_err(X86VcpuError::from)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsGuestNW::CS_BASE, entry_state.cs_base)
            .map_err(X86VcpuError::from)?;
        set_guest_segment!(SS, 0x93);
        set_guest_segment!(DS, 0x93);
        set_guest_segment!(FS, 0x93);
        set_guest_segment!(GS, 0x93);
        set_guest_segment!(TR, 0x8b); // present, system, 32-bit TSS busy
        set_guest_segment!(LDTR, 0x82); // present, system, LDT

        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsGuestNW::GDTR_BASE, 0)
            .map_err(X86VcpuError::from)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsGuest32::GDTR_LIMIT, 0xffff)
            .map_err(X86VcpuError::from)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsGuestNW::IDTR_BASE, 0)
            .map_err(X86VcpuError::from)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsGuest32::IDTR_LIMIT, 0xffff)
            .map_err(X86VcpuError::from)?;

        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsGuestNW::CR3, 0)
            .map_err(X86VcpuError::from)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsGuestNW::DR7, 0x400)
            .map_err(X86VcpuError::from)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsGuestNW::RSP, 0)
            .map_err(X86VcpuError::from)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsGuestNW::RIP, entry_state.rip)
            .map_err(X86VcpuError::from)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsGuestNW::RFLAGS, 0x2)
            .map_err(X86VcpuError::from)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsGuestNW::PENDING_DBG_EXCEPTIONS, 0)
            .map_err(X86VcpuError::from)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsGuestNW::IA32_SYSENTER_ESP, 0)
            .map_err(X86VcpuError::from)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsGuestNW::IA32_SYSENTER_EIP, 0)
            .map_err(X86VcpuError::from)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsGuest32::IA32_SYSENTER_CS, 0)
            .map_err(X86VcpuError::from)?;

        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsGuest32::INTERRUPTIBILITY_STATE, 0)
            .map_err(X86VcpuError::from)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsGuest32::ACTIVITY_STATE, 0)
            .map_err(X86VcpuError::from)?;

        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(
                VmcsGuest32::VMX_PREEMPTION_TIMER_VALUE,
                VMX_PREEMPTION_TIMER_SET_VALUE,
            )
            .map_err(X86VcpuError::from)?;

        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsGuest64::LINK_PTR, u64::MAX)
            .map_err(X86VcpuError::from)?; // SDM Vol. 3C, Section 24.4.2
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsGuest64::IA32_DEBUGCTL, 0)
            .map_err(X86VcpuError::from)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsGuest64::IA32_PAT, read_host_msr(Msr::Ia32Pat))
            .map_err(X86VcpuError::from)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsGuest64::IA32_EFER, 0)
            .map_err(X86VcpuError::from)?;
        Ok(())
    }

    fn setup_vmcs_control(
        &mut self,
        nested_page_table_root: X86HostPhysAddr,
        is_guest: bool,
    ) -> X86VcpuResult {
        // Intercept external interrupts and use the VMX preemption timer.
        use PinbasedControls as PinCtrl;

        use super::vmcs::controls::*;
        let raw_cpuid = CpuId::new();

        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .initialize_control(
                ax_cpu::virtualization::VmxControl::PinBased,
                (PinCtrl::EXTERNAL_INTERRUPT_EXITING | PinCtrl::VMX_PREEMPTION_TIMER).bits(),
                0,
            )?;

        // Intercept all I/O instructions, use MSR bitmaps, activate secondary controls,
        // disable CR3 load/store interception.
        use PrimaryControls as CpuCtrl;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .initialize_control(
                ax_cpu::virtualization::VmxControl::Primary,
                (CpuCtrl::USE_IO_BITMAPS
                    | CpuCtrl::USE_MSR_BITMAPS
                    | CpuCtrl::USE_TPR_SHADOW
                    | CpuCtrl::HLT_EXITING
                    | CpuCtrl::SECONDARY_CONTROLS)
                    .bits(),
                (CpuCtrl::CR3_LOAD_EXITING
                    | CpuCtrl::CR3_STORE_EXITING
                    | CpuCtrl::CR8_LOAD_EXITING
                    | CpuCtrl::CR8_STORE_EXITING)
                    .bits(),
            )?;

        // Enable EPT, RDTSCP, INVPCID, and unrestricted guest.
        use SecondaryControls as CpuCtrl2;
        let mut val = CpuCtrl2::ENABLE_EPT
            | CpuCtrl2::UNRESTRICTED_GUEST
            | supported_apic_virtualization_controls(secondary_control_bits_allowed);
        if let Some(features) = raw_cpuid.get_extended_processor_and_feature_identifiers()
            && features.has_rdtscp()
            && secondary_control_bits_allowed(CpuCtrl2::ENABLE_RDTSCP.bits())
        {
            val |= CpuCtrl2::ENABLE_RDTSCP;
        }
        if let Some(features) = raw_cpuid.get_extended_feature_info()
            && features.has_invpcid()
            && secondary_control_bits_allowed(CpuCtrl2::ENABLE_INVPCID.bits())
        {
            val |= CpuCtrl2::ENABLE_INVPCID;
        }
        if let Some(features) = raw_cpuid.get_extended_state_info()
            && features.has_xsaves_xrstors()
            && secondary_control_bits_allowed(CpuCtrl2::ENABLE_XSAVES_XRSTORS.bits())
        {
            val |= CpuCtrl2::ENABLE_XSAVES_XRSTORS;
        }
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .initialize_control(ax_cpu::virtualization::VmxControl::Secondary, val.bits(), 0)?;

        // Switch to 64-bit host, acknowledge interrupt info, switch IA32_PAT/IA32_EFER on VM exit.
        use ExitControls as ExitCtrl;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .initialize_control(
                ax_cpu::virtualization::VmxControl::Exit,
                (ExitCtrl::HOST_ADDRESS_SPACE_SIZE
                    | ExitCtrl::ACK_INTERRUPT_ON_EXIT
                    | ExitCtrl::SAVE_IA32_PAT
                    | ExitCtrl::LOAD_IA32_PAT
                    | ExitCtrl::SAVE_IA32_EFER
                    | ExitCtrl::LOAD_IA32_EFER)
                    .bits(),
                0,
            )?;

        let mut val = EntryCtrl::LOAD_IA32_PAT | EntryCtrl::LOAD_IA32_EFER;

        if !is_guest {
            // IA-32e mode guest
            // On processors that support Intel 64 architecture, this control determines whether the logical processor is in IA-32e mode after VM entry.
            // Its value is loaded into IA32_EFER.LMA as part of VM entry.
            val |= EntryCtrl::IA32E_MODE_GUEST;
        }

        // Load guest IA32_PAT/IA32_EFER on VM entry.
        use EntryControls as EntryCtrl;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .initialize_control(ax_cpu::virtualization::VmxControl::Entry, val.bits(), 0)?;

        vmcs::set_ept_pointer(
            self.cpu.vmx_controls_mut().expect("VMX policy CPU"),
            nested_page_table_root,
        )?;

        // No MSR switches if hypervisor doesn't use and there is only one vCPU.
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsControl32::VMEXIT_MSR_STORE_COUNT, 0)
            .map_err(X86VcpuError::from)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsControl32::VMEXIT_MSR_LOAD_COUNT, 0)
            .map_err(X86VcpuError::from)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsControl32::VMENTRY_MSR_LOAD_COUNT, 0)
            .map_err(X86VcpuError::from)?;

        // self.cpu.vmx_controls_mut().expect("VMX policy CPU").write(VmcsControlNW::CR4_GUEST_HOST_MASK, 0).map_err(X86VcpuError::from)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsControl32::CR3_TARGET_COUNT, 0)
            .map_err(X86VcpuError::from)?;

        // Pass through guest exceptions. Linux uses #UD (`ud2`) for BUG/WARN handling.
        let exception_bitmap: u32 = 0;

        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsControl32::EXCEPTION_BITMAP, exception_bitmap)
            .map_err(X86VcpuError::from)?;
        let controls = self.cpu.vmx_controls_mut().expect("VMX policy CPU");
        let [io_a, io_b] = controls.io_addresses();
        let msr = controls.msr_address();
        controls.write(VmcsControl64::IO_BITMAP_A_ADDR, io_a.as_usize() as u64)?;
        controls.write(VmcsControl64::IO_BITMAP_B_ADDR, io_b.as_usize() as u64)?;
        controls.write(VmcsControl64::MSR_BITMAPS_ADDR, msr.as_usize() as u64)?;

        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(
                VmcsControl64::VIRT_APIC_ADDR,
                self.vlapic.virtual_apic_page_addr().as_usize() as _,
            )
            .map_err(X86VcpuError::from)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(
                VmcsControl64::APIC_ACCESS_ADDR,
                EmulatedLocalApic::<H>::virtual_apic_access_addr().as_usize() as _,
            )
            .map_err(X86VcpuError::from)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsControl64::EOI_EXIT0, u64::MAX)
            .map_err(X86VcpuError::from)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsControl64::EOI_EXIT1, u64::MAX)
            .map_err(X86VcpuError::from)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsControl64::EOI_EXIT2, u64::MAX)
            .map_err(X86VcpuError::from)?;
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsControl64::EOI_EXIT3, u64::MAX)
            .map_err(X86VcpuError::from)?;
        Ok(())
    }

    fn get_paging_level(&self) -> usize {
        let mut level: u32 = 0; // non-paging
        let cr0 = self
            .cpu
            .vmx_controls()
            .expect("VMX policy CPU")
            .read(VmcsGuestNW::CR0)
            .map_err(X86VcpuError::from)
            .unwrap();
        let cr4 = self
            .cpu
            .vmx_controls()
            .expect("VMX policy CPU")
            .read(VmcsGuestNW::CR4)
            .map_err(X86VcpuError::from)
            .unwrap();
        let efer = self
            .cpu
            .vmx_controls()
            .expect("VMX policy CPU")
            .read(VmcsGuest64::IA32_EFER)
            .map_err(X86VcpuError::from)
            .unwrap();
        // paging is enabled
        if cr0 & Cr0Flags::PAGING.bits() as usize != 0 {
            if cr4 & Cr4Flags::PHYSICAL_ADDRESS_EXTENSION.bits() as usize != 0 {
                // is long mode
                if efer & EferFlags::LONG_MODE_ACTIVE.bits() != 0 {
                    level = 4;
                } else {
                    level = 3;
                }
            } else {
                level = 2;
            }
        }
        level as usize
    }
}

// Implementaton for type1.5 hypervisor
// #[cfg(feature = "type1_5")]
impl<H: X86HostOps, M: ControlMemory> VmxVcpu<H, M> {
    fn set_cr(&mut self, cr_idx: usize, val: u64) {
        (|| -> X86VcpuResult {
            // debug!("set guest CR{} to val {:#x}", cr_idx, val);
            match cr_idx {
                0 => {
                    // Retrieve/validate restrictions on CR0
                    //
                    // In addition to what the VMX MSRs tell us, make sure that
                    // - NW and CD are kept off as they are not updated on VM exit and we
                    //   don't want them enabled for performance reasons while in root mode
                    // - PE and PG can be freely chosen (by the guest) because we demand
                    //   unrestricted guest mode support anyway
                    // - ET is ignored
                    let must0 = read_host_msr(Msr::Ia32VmxCr0Fixed1)
                        & !(Cr0Flags::NOT_WRITE_THROUGH | Cr0Flags::CACHE_DISABLE).bits();
                    let must1 = read_host_msr(Msr::Ia32VmxCr0Fixed0)
                        & !(Cr0Flags::PAGING | Cr0Flags::PROTECTED_MODE_ENABLE).bits();
                    self.cpu
                        .vmx_controls_mut()
                        .expect("VMX policy CPU")
                        .write(VmcsGuestNW::CR0, ((val & must0) | must1) as _)
                        .map_err(X86VcpuError::from)?;
                    self.cpu
                        .vmx_controls_mut()
                        .expect("VMX policy CPU")
                        .write(VmcsControlNW::CR0_READ_SHADOW, val as _)
                        .map_err(X86VcpuError::from)?;
                    self.cpu
                        .vmx_controls_mut()
                        .expect("VMX policy CPU")
                        .write(VmcsControlNW::CR0_GUEST_HOST_MASK, (must1 | !must0) as _)
                        .map_err(X86VcpuError::from)?;
                }
                3 => self
                    .cpu
                    .vmx_controls_mut()
                    .expect("VMX policy CPU")
                    .write(VmcsGuestNW::CR3, val as _)
                    .map_err(X86VcpuError::from)?,
                4 => {
                    // Retrieve/validate restrictions on CR4
                    let must0 = read_host_msr(Msr::Ia32VmxCr4Fixed1);
                    let must1 = read_host_msr(Msr::Ia32VmxCr4Fixed0);
                    let val = val | Cr4Flags::VIRTUAL_MACHINE_EXTENSIONS.bits();
                    self.cpu
                        .vmx_controls_mut()
                        .expect("VMX policy CPU")
                        .write(VmcsGuestNW::CR4, ((val & must0) | must1) as _)
                        .map_err(X86VcpuError::from)?;
                    self.cpu
                        .vmx_controls_mut()
                        .expect("VMX policy CPU")
                        .write(VmcsControlNW::CR4_READ_SHADOW, val as _)
                        .map_err(X86VcpuError::from)?;
                    self.cpu
                        .vmx_controls_mut()
                        .expect("VMX policy CPU")
                        .write(VmcsControlNW::CR4_GUEST_HOST_MASK, (must1 | !must0) as _)
                        .map_err(X86VcpuError::from)?;
                }
                _ => unreachable!(),
            };
            Ok(())
        })()
        .expect("Failed to write guest control register")
    }

    #[allow(dead_code)]
    fn cr(&self, cr_idx: usize) -> usize {
        (|| -> X86VcpuResult<usize> {
            Ok(match cr_idx {
                0 => self
                    .cpu
                    .vmx_controls()
                    .expect("VMX policy CPU")
                    .read(VmcsGuestNW::CR0)
                    .map_err(X86VcpuError::from)?,
                3 => self
                    .cpu
                    .vmx_controls()
                    .expect("VMX policy CPU")
                    .read(VmcsGuestNW::CR3)
                    .map_err(X86VcpuError::from)?,
                4 => {
                    let host_mask = self
                        .cpu
                        .vmx_controls()
                        .expect("VMX policy CPU")
                        .read(VmcsControlNW::CR4_GUEST_HOST_MASK)
                        .map_err(X86VcpuError::from)?;
                    (self
                        .cpu
                        .vmx_controls()
                        .expect("VMX policy CPU")
                        .read(VmcsControlNW::CR4_READ_SHADOW)
                        .map_err(X86VcpuError::from)?
                        & host_mask)
                        | (self
                            .cpu
                            .vmx_controls()
                            .expect("VMX policy CPU")
                            .read(VmcsGuestNW::CR4)
                            .map_err(X86VcpuError::from)?
                            & !host_mask)
                }
                _ => unreachable!(),
            })
        })()
        .expect("Failed to read guest control register")
    }
}

impl<H: X86HostOps, M: ControlMemory> VmxVcpu<H, M> {
    /// Whether the guest interrupts are blocked. (SDM Vol. 3C, Section 24.4.2, Table 24-3)
    fn allow_interrupt(&self) -> bool {
        let rflags = self
            .cpu
            .vmx_controls()
            .expect("VMX policy CPU")
            .read(VmcsGuestNW::RFLAGS)
            .map_err(X86VcpuError::from)
            .unwrap();
        let block_state = self
            .cpu
            .vmx_controls()
            .expect("VMX policy CPU")
            .read(VmcsGuest32::INTERRUPTIBILITY_STATE)
            .map_err(X86VcpuError::from)
            .unwrap();
        vmx_external_interrupt_allowed(rflags as u64, block_state)
    }

    /// Try to inject a pending event before next VM entry.
    fn inject_pending_events(&mut self) -> X86VcpuResult {
        if let Some(vector) = self.vlapic.take_pending_timer_interrupt()
            && let Err(error) = self.queue_fixed_apic_interrupt(vector, false)
        {
            warn!("ignoring invalid local APIC timer vector {vector:#x}: {error:?}");
        }
        if self.injecting_event.is_some() {
            return Ok(());
        }

        if let Some(event) = self.reinjection_event {
            if event.int_type == VmxInterruptionType::External {
                self.set_interrupt_window(false)?;
            }
            self.cpu
                .vmx_controls_mut()
                .expect("VMX policy CPU")
                .inject_interrupt(
                    VmxInterruptInfo {
                        vector: event.event.vector,
                        int_type: event.int_type,
                        err_code: event.event.err_code,
                        valid: true,
                    },
                    event.instruction_len.unwrap_or(0),
                )?;
            self.injecting_event = Some(event);
            self.reinjection_event = None;
            return Ok(());
        }

        if self.pending_events.is_empty() {
            return Ok(());
        }
        let interrupts_allowed = self.allow_interrupt();
        if let Some((index, event)) =
            select_pending_event(&self.pending_events, interrupts_allowed, |vector| {
                self.vlapic.can_accept_interrupt(vector)
            })
        {
            vmcs::inject_event(self.cpu.vmx_controls_mut().expect("VMX policy CPU"), event)?;
            if event.requires_vlapic_accept() {
                self.vlapic
                    .accept_interrupt(event.vector, event.level_triggered);
            }
            self.injecting_event = Some(VmxInjectionEvent::pending(event));
            self.pending_events.remove(index);
        } else if needs_interrupt_window(&self.pending_events, interrupts_allowed) {
            self.set_interrupt_window(true)?;
        }
        Ok(())
    }

    fn complete_event_injection(&mut self, exit_info: &VmxExitInfo) -> X86VcpuResult {
        let vectoring = self
            .cpu
            .vmx_controls()
            .expect("VMX policy CPU")
            .idt_vectoring_info()
            .map_err(X86VcpuError::from)?;
        self.reinjection_event = interrupted_vmx_event(
            vectoring,
            exit_info.exit_instruction_length,
            self.injecting_event,
        );
        self.injecting_event = None;
        Ok(())
    }

    fn handle_interrupt_window(&mut self) -> X86VcpuResult {
        self.set_interrupt_window(false)?;
        self.inject_pending_events()
    }

    /// Handle vm-exits than can and should be handled by [`VmxVcpu`] itself.
    ///
    /// Return the result or None if the vm-exit was not handled.
    fn builtin_vmexit_handler(&mut self, exit_info: &VmxExitInfo) -> Option<X86VcpuResult> {
        const APIC_BASE_MSR: u32 = 0x1b;
        const AMD64_DE_CFG: u32 = 0xc001_1029;
        // Following vm-exits are handled here:
        // - interrupt window: turn off interrupt window;
        // - xsetbv: set guest xcr;
        // - cr access: just panic;
        match exit_info.exit_reason.ok()? {
            VmxExitReason::InterruptWindow => Some(self.handle_interrupt_window()),
            VmxExitReason::Xsetbv => Some(self.handle_xsetbv()),
            VmxExitReason::CrAccess => Some(self.handle_cr()),
            VmxExitReason::Cpuid => Some(self.handle_cpuid()),
            msr_rw @ (VmxExitReason::MsrRead | VmxExitReason::MsrWrite)
                if self.regs().rcx as u32 == APIC_BASE_MSR =>
            {
                Some(self.handle_apic_base_msr_access(msr_rw == VmxExitReason::MsrWrite))
            }
            msr_rw @ (VmxExitReason::MsrRead | VmxExitReason::MsrWrite)
                if self.regs().rcx as u32 == AMD64_DE_CFG =>
            {
                Some(self.handle_amd64_de_cfg_msr_access(msr_rw == VmxExitReason::MsrWrite))
            }
            _ => None,
        }
    }

    /// Read a 64-bit value from EDX:EAX.
    fn read_edx_eax(&self) -> u64 {
        ((self.regs().rdx & 0xffff_ffff) << 32) | (self.regs().rax & 0xffff_ffff)
    }

    /// Write a 64-bit value to EDX:EAX.
    fn write_edx_eax(&mut self, val: u64) {
        self.regs_mut().rax = val & 0xffff_ffff;
        self.regs_mut().rdx = val >> 32;
    }

    fn handle_apic_base_msr_access(&mut self, write: bool) -> X86VcpuResult {
        const VMEXIT_INSTR_LEN_RDMSR_WRMSR: u8 = 2;

        self.advance_rip(VMEXIT_INSTR_LEN_RDMSR_WRMSR)?;

        if write {
            let value = self.read_edx_eax();
            trace!("handle_vlapic_apic_base_write: value={value:#x}");
            self.vlapic
                .set_apic_base(value)
                .map_err(|_| X86VcpuError::BadState)
        } else {
            let value = self.vlapic.apic_base();
            trace!("handle_vlapic_apic_base_read: value={value:#x}");
            self.write_edx_eax(value);
            Ok(())
        }
    }

    fn handle_apic_msr_access(&mut self, write: bool, msr: u32) -> X86VcpuResult<X86VmExit> {
        const VMEXIT_INSTR_LEN_RDMSR_WRMSR: u8 = 2;

        self.advance_rip(VMEXIT_INSTR_LEN_RDMSR_WRMSR)?;

        let reg = msr as usize;
        if write {
            let value = self.read_edx_eax() as usize;

            trace!("handle_vlapic_msr_write: msr={msr:#x}, value={value:#x}");

            if msr == X2APIC_EOI_MSR {
                Ok(X86VmExit::InterruptEnd {
                    vector: self.vlapic.handle_eoi(),
                })
            } else {
                self.vlapic
                    .handle_msr_write(
                        x86_vlapic::X86MsrAddr::new(reg),
                        x86_vlapic::X86AccessWidth::Qword,
                        value,
                    )
                    .map_err(|_| X86VcpuError::BadState)?;
                Ok(X86VmExit::Nothing)
            }
        } else {
            let value = self
                .vlapic
                .handle_msr_read(
                    x86_vlapic::X86MsrAddr::new(reg),
                    x86_vlapic::X86AccessWidth::Qword,
                )
                .map_err(|_| X86VcpuError::BadState)? as u64;

            trace!("handle_vlapic_msr_read: msr={msr:#x}, value={value:#x}");

            self.write_edx_eax(value);
            Ok(X86VmExit::Nothing)
        }
    }

    fn handle_amd64_de_cfg_msr_access(&mut self, write: bool) -> X86VcpuResult {
        const VMEXIT_INSTR_LEN_RDMSR_WRMSR: u8 = 2;

        self.advance_rip(VMEXIT_INSTR_LEN_RDMSR_WRMSR)?;
        if !write {
            self.write_edx_eax(0);
        }
        Ok(())
    }

    fn handle_apic_access(&mut self, exit_info: &VmxExitInfo) -> X86VcpuResult<X86VmExit> {
        let apic_access_exit_info = self.apic_access_exit_info()?;

        let write = match apic_access_exit_info.access_type {
            ApicAccessExitType::LinearDataWrite => true,
            ApicAccessExitType::LinearDataRead => false,
            _ => {
                debug!(
                    "Ignoring non-data APIC access type: {:?}",
                    apic_access_exit_info.access_type
                );
                return Ok(X86VmExit::Nothing);
            }
        };

        let reg = apic_access_exit_info.offset as usize;
        let addr = X86GuestPhysAddr::from(X86_LOCAL_APIC_GPA + reg);
        let mut exit_reason = X86VmExit::Nothing;
        if write {
            let value = self.decode_apic_mmio_write_value(exit_info)?;
            if reg == X86_LOCAL_APIC_EOI_OFFSET {
                exit_reason = X86VmExit::InterruptEnd {
                    vector: self.vlapic.handle_eoi(),
                };
            } else {
                self.vlapic
                    .handle_mmio_write(
                        x86_vlapic::X86GuestPhysAddr::from_usize(addr.as_usize()),
                        x86_vlapic::X86AccessWidth::Dword,
                        value,
                    )
                    .map_err(|_| X86VcpuError::BadState)?;
            }
        } else {
            let value = self
                .vlapic
                .handle_mmio_read(
                    x86_vlapic::X86GuestPhysAddr::from_usize(addr.as_usize()),
                    x86_vlapic::X86AccessWidth::Dword,
                )
                .map_err(|_| X86VcpuError::BadState)?;
            self.regs_mut().rax = value as u64;
        }

        self.advance_rip(exit_info.exit_instruction_length as _)?;
        Ok(exit_reason)
    }

    fn decode_apic_mmio_write_value(&self, exit_info: &VmxExitInfo) -> X86VcpuResult<usize> {
        let mut rip = self.gla2gva(X86GuestVirtAddr::from(exit_info.guest_rip));
        let mut rex = 0u8;
        let mut _operand_size_override = false;

        Self::skip_simple_prefixes(self, &mut rip, &mut rex, &mut _operand_size_override)?;

        let opcode = self.read_guest_u8(rip)?;
        rip += 1;
        let modrm = self.read_guest_u8(rip)?;
        rip += 1;
        let mode = modrm >> 6;
        if mode == 0b11 {
            return x86_err!(Unsupported, "APIC MMIO write destination is not memory");
        }

        if opcode == 0x89 {
            let reg = ((modrm >> 3) & 0x7) | ((rex & 0x4) << 1);
            return Ok(self.cpu.registers().get_reg_of_index(reg) as u32 as usize);
        }

        if opcode == 0xc7 && (modrm >> 3) & 0x7 == 0 {
            let imm_addr = self.skip_modrm_memory_operand(rip, modrm, rex)?;
            let mut value = 0u32;
            for i in 0..size_of::<u32>() {
                value |= (self.read_guest_u8(imm_addr + i)? as u32) << (i * 8);
            }
            return Ok(value as usize);
        }

        x86_err!(
            Unsupported,
            format_args!("unsupported APIC MMIO write opcode {opcode:#x}")
        )
    }

    fn decode_ept_mmio_access(
        &mut self,
        exit_info: &VmxExitInfo,
        addr: X86GuestPhysAddr,
        write: bool,
    ) -> Option<(X86VmExit, u8)> {
        let addr_usize = addr.as_usize();
        let local_apic =
            (X86_LOCAL_APIC_GPA..X86_LOCAL_APIC_GPA + X86_LOCAL_APIC_SIZE).contains(&addr_usize);
        let ioapic = (X86_IOAPIC_BASE..X86_IOAPIC_BASE + X86_IOAPIC_SIZE).contains(&addr_usize);
        let device_mmio = self
            .intercepted_mmio
            .iter()
            .any(|range| range.contains(addr));
        if !local_apic && !ioapic && !device_mmio {
            return None;
        }

        let start = self.gla2gva(X86GuestVirtAddr::from(exit_info.guest_rip));
        let mut rip = start;
        let mut rex = 0u8;
        let mut operand_size_override = false;
        if let Err(err) =
            Self::skip_simple_prefixes(self, &mut rip, &mut rex, &mut operand_size_override)
        {
            debug!("failed to decode EPT MMIO prefixes: {err:?}");
            return None;
        }

        let opcode = self.read_guest_u8(rip).ok()?;
        rip += 1;
        let modrm = self.read_guest_u8(rip).ok()?;
        rip += 1;
        if modrm >> 6 == 0b11 {
            debug!("EPT MMIO access did not use a memory operand");
            return None;
        }

        if local_apic || ioapic {
            return self.decode_ept_apic_mmio_access(
                crate::arch::x86_64::policy::decode::X86ApicMmioDecode {
                    start,
                    rip,
                    modrm,
                    rex,
                    opcode,
                    addr,
                    write,
                    local_apic,
                },
            );
        }

        let rex_w = rex & 0x8 != 0;
        match (write, opcode) {
            (true, 0x88) => {
                let byte_reg = crate::arch::x86_64::policy::decode::x86_byte_register(
                    (modrm >> 3) & 0x7,
                    rex,
                )?;
                let end = self.skip_modrm_memory_operand(rip, modrm, rex).ok()?;
                let data = self.read_byte_register(byte_reg)?;
                let exit = crate::arch::x86_64::policy::decode::mov_mmio_write_exit(
                    addr,
                    opcode,
                    operand_size_override,
                    rex_w,
                    data,
                )?;
                Some((exit, (end.as_usize() - start.as_usize()) as u8))
            }
            (true, 0x89) => {
                let reg = ((modrm >> 3) & 0x7) | ((rex & 0x4) << 1);
                let end = self.skip_modrm_memory_operand(rip, modrm, rex).ok()?;
                let data = if reg == 4 {
                    self.read_rsp()?
                } else {
                    self.cpu.registers().get_reg_of_index(reg)
                };
                let exit = crate::arch::x86_64::policy::decode::mov_mmio_write_exit(
                    addr,
                    opcode,
                    operand_size_override,
                    rex_w,
                    data,
                )?;
                Some((exit, (end.as_usize() - start.as_usize()) as u8))
            }
            (true, 0xc6 | 0xc7) if (modrm >> 3) & 0x7 == 0 => {
                let width = X86AccessWidth::for_mov_opcode(opcode, operand_size_override, rex_w)?;
                let imm_addr = self.skip_modrm_memory_operand(rip, modrm, rex).ok()?;
                let data = self.read_mmio_immediate(imm_addr, width).ok()?;
                let exit = self.handle_decoded_ept_mmio_write(addr, data, false, width)?;
                let instr_len = imm_addr.as_usize()
                    + crate::arch::x86_64::policy::decode::mov_immediate_size(width)
                    - start.as_usize();
                Some((exit, instr_len as u8))
            }
            (false, 0x8a) => {
                let byte_reg = crate::arch::x86_64::policy::decode::x86_byte_register(
                    (modrm >> 3) & 0x7,
                    rex,
                )?;
                let end = self.skip_modrm_memory_operand(rip, modrm, rex).ok()?;
                let exit = X86VmExit::MmioRead {
                    addr,
                    width: X86AccessWidth::Byte,
                    reg: byte_reg.gpr as usize,
                    reg_width: X86AccessWidth::Byte,
                    signed_ext: false,
                    byte_reg: Some(byte_reg),
                    next_rip: UNRESOLVED_NEXT_RIP,
                };
                Some((exit, (end.as_usize() - start.as_usize()) as u8))
            }
            (false, 0x8b) => {
                let width = X86AccessWidth::for_mov_opcode(opcode, operand_size_override, rex_w)?;
                let reg = (((modrm >> 3) & 0x7) | ((rex & 0x4) << 1)) as usize;
                let end = self.skip_modrm_memory_operand(rip, modrm, rex).ok()?;
                let exit = X86VmExit::MmioRead {
                    addr,
                    width,
                    reg,
                    reg_width: width,
                    signed_ext: false,
                    byte_reg: None,
                    next_rip: UNRESOLVED_NEXT_RIP,
                };
                Some((exit, (end.as_usize() - start.as_usize()) as u8))
            }
            _ => {
                debug!("unsupported EPT MMIO opcode {opcode:#x}, write={write}");
                None
            }
        }
    }

    fn decode_ept_apic_mmio_access(
        &mut self,
        decode: crate::arch::x86_64::policy::decode::X86ApicMmioDecode,
    ) -> Option<(X86VmExit, u8)> {
        let crate::arch::x86_64::policy::decode::X86ApicMmioDecode {
            start,
            rip,
            modrm,
            rex,
            opcode,
            addr,
            write,
            local_apic,
        } = decode;

        match (write, opcode) {
            (true, 0x89) => {
                let reg = ((modrm >> 3) & 0x7) | ((rex & 0x4) << 1);
                let end = self.skip_modrm_memory_operand(rip, modrm, rex).ok()?;
                let data = self.cpu.registers().get_reg_of_index(reg) as u32 as u64;
                let exit = self.handle_decoded_ept_mmio_write(
                    addr,
                    data,
                    local_apic,
                    X86AccessWidth::Dword,
                )?;
                Some((exit, (end.as_usize() - start.as_usize()) as u8))
            }
            (true, 0xc7) if (modrm >> 3) & 0x7 == 0 => {
                let imm_addr = self.skip_modrm_memory_operand(rip, modrm, rex).ok()?;
                let mut data = 0u32;
                for i in 0..size_of::<u32>() {
                    data |= (self.read_guest_u8(imm_addr + i).ok()? as u32) << (i * 8);
                }
                let exit = self.handle_decoded_ept_mmio_write(
                    addr,
                    data as u64,
                    local_apic,
                    X86AccessWidth::Dword,
                )?;
                Some((
                    exit,
                    (imm_addr.as_usize() + size_of::<u32>() - start.as_usize()) as u8,
                ))
            }
            (false, 0x8b) => {
                let reg = (((modrm >> 3) & 0x7) | ((rex & 0x4) << 1)) as usize;
                let end = self.skip_modrm_memory_operand(rip, modrm, rex).ok()?;
                let exit = if local_apic {
                    let val = self
                        .vlapic
                        .handle_mmio_read(
                            x86_vlapic::X86GuestPhysAddr::from_usize(addr.as_usize()),
                            x86_vlapic::X86AccessWidth::Dword,
                        )
                        .ok()?;
                    self.regs_mut()
                        .set_reg_of_index(reg as u8, val as u32 as u64);
                    X86VmExit::Nothing
                } else {
                    X86VmExit::MmioRead {
                        addr,
                        width: X86AccessWidth::Dword,
                        reg,
                        reg_width: X86AccessWidth::Dword,
                        signed_ext: false,
                        byte_reg: None,
                        next_rip: UNRESOLVED_NEXT_RIP,
                    }
                };
                Some((exit, (end.as_usize() - start.as_usize()) as u8))
            }
            _ => {
                debug!("unsupported EPT MMIO opcode {opcode:#x}, write={write}");
                None
            }
        }
    }

    fn read_mmio_immediate(
        &self,
        imm_addr: X86GuestVirtAddr,
        width: X86AccessWidth,
    ) -> X86VcpuResult<u64> {
        match width {
            X86AccessWidth::Byte => Ok(self.read_guest_u8(imm_addr)? as u64),
            X86AccessWidth::Word => {
                let mut data = 0u64;
                for i in 0..size_of::<u16>() {
                    data |= (self.read_guest_u8(imm_addr + i)? as u64) << (i * 8);
                }
                Ok(data)
            }
            X86AccessWidth::Dword => {
                let mut data = 0u64;
                for i in 0..size_of::<u32>() {
                    data |= (self.read_guest_u8(imm_addr + i)? as u64) << (i * 8);
                }
                Ok(data)
            }
            X86AccessWidth::Qword => {
                // C7 with REX.W still encodes a 32-bit immediate; the CPU
                // sign-extends it to 64 bits before storing.
                let mut imm = 0u32;
                for i in 0..size_of::<u32>() {
                    imm |= (self.read_guest_u8(imm_addr + i)? as u32) << (i * 8);
                }
                Ok((imm as i32) as i64 as u64)
            }
        }
    }

    fn read_byte_register(&self, byte_reg: X86ByteRegister) -> Option<u64> {
        if byte_reg.gpr == 4 {
            return Some(
                (self
                    .cpu
                    .vmx_controls()
                    .expect("VMX policy CPU")
                    .read(VmcsGuestNW::RSP)
                    .map_err(X86VcpuError::from)
                    .ok()? as u64)
                    & 0xff,
            );
        }
        let value = self.cpu.registers().get_reg_of_index(byte_reg.gpr);
        Some(u64::from(
            crate::arch::x86_64::policy::decode::x86_byte_register_value(value, byte_reg),
        ))
    }

    fn read_rsp(&self) -> Option<u64> {
        Some(
            self.cpu
                .vmx_controls()
                .expect("VMX policy CPU")
                .read(VmcsGuestNW::RSP)
                .map_err(X86VcpuError::from)
                .ok()? as u64,
        )
    }

    fn write_rsp(&mut self, value: u64) -> X86VcpuResult {
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(VmcsGuestNW::RSP, value as usize)
            .map_err(X86VcpuError::from)
    }

    fn write_byte_register(&mut self, byte_reg: X86ByteRegister, value: u8) -> X86VcpuResult {
        if byte_reg.gpr == 4 {
            let old = self
                .cpu
                .vmx_controls()
                .expect("VMX policy CPU")
                .read(VmcsGuestNW::RSP)
                .map_err(X86VcpuError::from)?;
            self.cpu
                .vmx_controls_mut()
                .expect("VMX policy CPU")
                .write(VmcsGuestNW::RSP, (old & !0xff) | usize::from(value))
                .map_err(X86VcpuError::from)?;
            return Ok(());
        }
        let gpr = byte_reg.gpr;
        let old = self.cpu.registers().get_reg_of_index(gpr);
        let new =
            crate::arch::x86_64::policy::decode::x86_byte_register_merge(old, byte_reg, value);
        self.regs_mut().set_reg_of_index(gpr, new);
        Ok(())
    }

    fn write_word_register(&mut self, reg: usize, value: u16) -> X86VcpuResult {
        if reg == 4 {
            let old = self
                .cpu
                .vmx_controls()
                .expect("VMX policy CPU")
                .read(VmcsGuestNW::RSP)
                .map_err(X86VcpuError::from)?;
            let merged =
                crate::arch::x86_64::policy::decode::x86_word_register_merge(old as u64, value);
            self.cpu
                .vmx_controls_mut()
                .expect("VMX policy CPU")
                .write(VmcsGuestNW::RSP, merged as usize)
                .map_err(X86VcpuError::from)?;
            return Ok(());
        }
        let old = self.cpu.registers().get_reg_of_index(reg as u8);
        let new = crate::arch::x86_64::policy::decode::x86_word_register_merge(old, value);
        self.regs_mut().set_reg_of_index(reg as u8, new);
        Ok(())
    }

    fn handle_decoded_ept_mmio_write(
        &mut self,
        addr: X86GuestPhysAddr,
        data: u64,
        local_apic: bool,
        width: X86AccessWidth,
    ) -> Option<X86VmExit> {
        if !local_apic {
            return Some(X86VmExit::MmioWrite {
                addr,
                width,
                data,
                next_rip: UNRESOLVED_NEXT_RIP,
            });
        }

        let offset = addr.as_usize() - X86_LOCAL_APIC_GPA;
        if offset == X86_LOCAL_APIC_EOI_OFFSET {
            return Some(X86VmExit::InterruptEnd {
                vector: self.vlapic.handle_eoi(),
            });
        }

        self.vlapic
            .handle_mmio_write(
                x86_vlapic::X86GuestPhysAddr::from_usize(addr.as_usize()),
                x86_vlapic::X86AccessWidth::Dword,
                data as usize,
            )
            .ok()?;
        Some(X86VmExit::Nothing)
    }

    fn skip_simple_prefixes(
        &self,
        rip: &mut X86GuestVirtAddr,
        rex: &mut u8,
        operand_size_override: &mut bool,
    ) -> X86VcpuResult {
        loop {
            let byte = self.read_guest_u8(*rip)?;
            if crate::arch::x86_64::policy::decode::x86_simple_prefix_update(
                byte,
                rex,
                operand_size_override,
            ) {
                *rip += 1;
            } else {
                return Ok(());
            }
        }
    }

    fn skip_modrm_memory_operand(
        &self,
        mut cursor: X86GuestVirtAddr,
        modrm: u8,
        rex: u8,
    ) -> X86VcpuResult<X86GuestVirtAddr> {
        let rm = modrm & 0x7;
        let mut sib = None;

        if rm == 0b100 {
            let byte = self.read_guest_u8(cursor)?;
            cursor += 1;
            sib = Some(byte);
        }

        let disp_size =
            crate::arch::x86_64::policy::decode::x86_modrm_displacement_size(modrm, sib, rex)
                .ok_or_else(|| {
                    x86_err_type!(InvalidInput, "ModRM register operand is not memory")
                })?;
        cursor += disp_size;

        Ok(cursor)
    }

    fn read_guest_u8(&self, gva: X86GuestVirtAddr) -> X86VcpuResult<u8> {
        let gpa = self.translate_guest_linear(gva)?;
        self.read_guest_phys_u8(gpa)
    }

    fn guest_phys_to_host_virt(&self, gpa: X86GuestPhysAddr) -> X86VcpuResult<usize> {
        let gpa = gpa.as_usize();
        self.guest_memory_regions
            .iter()
            .find_map(|region| {
                let start = region.gpa.as_usize();
                let offset = gpa.checked_sub(start)?;
                if offset < region.size {
                    region.hva.as_usize().checked_add(offset)
                } else {
                    None
                }
            })
            .ok_or_else(|| {
                x86_err_type!(
                    InvalidInput,
                    format_args!("guest physical address {gpa:#x} is not backed by RAM")
                )
            })
    }

    fn read_guest_phys_u8(&self, gpa: X86GuestPhysAddr) -> X86VcpuResult<u8> {
        if self.guest_memory_regions.is_empty() {
            return host::read_guest_u8::<H>(gpa);
        }

        let hva = self.guest_phys_to_host_virt(gpa)?;
        Ok(unsafe { core::ptr::read_volatile(hva as *const u8) })
    }

    fn read_guest_phys_u64(&self, gpa: X86GuestPhysAddr) -> X86VcpuResult<u64> {
        let mut bytes = [0u8; 8];
        for (offset, byte) in bytes.iter_mut().enumerate() {
            let addr = gpa
                .as_usize()
                .checked_add(offset)
                .ok_or(X86VcpuError::InvalidInput)?;
            *byte = self.read_guest_phys_u8(X86GuestPhysAddr::from_usize(addr))?;
        }
        Ok(u64::from_le_bytes(bytes))
    }

    fn translate_guest_linear(&self, gva: X86GuestVirtAddr) -> X86VcpuResult<X86GuestPhysAddr> {
        let addr = gva.as_usize();
        match self.get_paging_level() {
            0 => Ok(X86GuestPhysAddr::from(addr)),
            4 => self.walk_guest_page_table_4level(addr),
            level => x86_err!(
                Unsupported,
                format_args!("unsupported APIC MMIO write decode paging level {level}")
            ),
        }
    }

    fn walk_guest_page_table_4level(&self, gva: usize) -> X86VcpuResult<X86GuestPhysAddr> {
        const PRESENT: u64 = 1 << 0;
        const HUGE_PAGE: u64 = 1 << 7;
        const ADDR_MASK: u64 = 0x000f_ffff_ffff_f000;
        const PAGE_4K_MASK: usize = 0xfff;
        const PAGE_2M_MASK: usize = 0x1f_ffff;
        const PAGE_1G_MASK: usize = 0x3fff_ffff;

        let mut table = self
            .cpu
            .vmx_controls()
            .expect("VMX policy CPU")
            .read(VmcsGuestNW::CR3)
            .map_err(X86VcpuError::from)?
            & ADDR_MASK as usize;
        let indexes = [
            (gva >> 39) & 0x1ff,
            (gva >> 30) & 0x1ff,
            (gva >> 21) & 0x1ff,
            (gva >> 12) & 0x1ff,
        ];

        for (level, index) in indexes.into_iter().enumerate() {
            let entry =
                self.read_guest_phys_u64(X86GuestPhysAddr::from(table + index * size_of::<u64>()))?;
            if entry & PRESENT == 0 {
                return x86_err!(
                    InvalidInput,
                    format_args!("guest RIP page table entry is not present at level {level}")
                );
            }

            let paddr = (entry & ADDR_MASK) as usize;
            match level {
                1 if entry & HUGE_PAGE != 0 => {
                    return Ok(X86GuestPhysAddr::from(paddr + (gva & PAGE_1G_MASK)));
                }
                2 if entry & HUGE_PAGE != 0 => {
                    return Ok(X86GuestPhysAddr::from(paddr + (gva & PAGE_2M_MASK)));
                }
                3 => return Ok(X86GuestPhysAddr::from(paddr + (gva & PAGE_4K_MASK))),
                _ => table = paddr,
            }
        }

        x86_err!(InvalidInput, "failed to translate guest RIP")
    }

    fn handle_vmx_preemption_timer(&mut self) -> X86VcpuResult {
        // The VMX-preemption timer counts down at rate proportional to that of the timestamp counter (TSC).
        // Specifically, the timer counts down by 1 every time bit X in the TSC changes due to a TSC increment.
        // The value of X is in the range 0–31 and can be determined by consulting the VMX capability MSR IA32_VMX_MISC (see Appendix A.6).
        self.cpu
            .vmx_controls_mut()
            .expect("VMX policy CPU")
            .write(
                VmcsGuest32::VMX_PREEMPTION_TIMER_VALUE,
                VMX_PREEMPTION_TIMER_SET_VALUE,
            )
            .map_err(X86VcpuError::from)?;
        Ok(())
    }

    #[allow(clippy::single_match)]
    fn handle_cr(&mut self) -> X86VcpuResult {
        const VM_EXIT_INSTR_LEN_MV_TO_CR: u8 = 3;

        let cr_access_info =
            vmcs::cr_access_info(self.cpu.vmx_controls().expect("VMX policy CPU"))?;

        let reg = cr_access_info.gpr;
        let cr = cr_access_info.cr_number;

        match cr_access_info.access_type {
            // move to cr
            0 => {
                let val = if reg == 4 {
                    self.stack_pointer() as u64
                } else {
                    self.cpu.registers().get_reg_of_index(reg)
                };
                if cr == 0 || cr == 4 {
                    self.advance_rip(VM_EXIT_INSTR_LEN_MV_TO_CR)?;
                    // TODO: check for #GP reasons
                    self.set_cr(cr as usize, val);

                    if cr == 0 {
                        self.cpu
                            .vmx_controls_mut()
                            .expect("VMX policy CPU")
                            .synchronize_long_mode(val)?;
                    }
                    return Ok(());
                }
            }
            _ => {}
        };

        panic!(
            "Guest's access to cr not allowed: {:#x?}, {:#x?}",
            self, cr_access_info
        );
    }

    fn handle_cpuid(&mut self) -> X86VcpuResult {
        use raw_cpuid::{CpuIdResult, cpuid};

        const VM_EXIT_INSTR_LEN_CPUID: u8 = 2;
        const LEAF_FEATURE_INFO: u32 = 0x1;
        const LEAF_STRUCTURED_EXTENDED_FEATURE_FLAGS_ENUMERATION: u32 = 0x7;
        const LEAF_PROCESSOR_EXTENDED_STATE_ENUMERATION: u32 = 0xd;
        const EAX_FREQUENCY_INFO: u32 = 0x16;
        const LEAF_HYPERVISOR_INFO: u32 = 0x4000_0000;
        const LEAF_HYPERVISOR_FEATURE: u32 = 0x4000_0001;
        const VENDOR_STR: &[u8; 12] = b"RVMRVMRVMRVM";
        let vendor_regs: [u32; 3] = core::array::from_fn(|word| {
            let offset = word * 4;
            u32::from_le_bytes([
                VENDOR_STR[offset],
                VENDOR_STR[offset + 1],
                VENDOR_STR[offset + 2],
                VENDOR_STR[offset + 3],
            ])
        });

        let regs_clone = *self.regs_mut();
        let function = regs_clone.rax as u32;
        let res = match function {
            LEAF_FEATURE_INFO => {
                const FEATURE_VMX: u32 = 1 << 5;
                const FEATURE_HYPERVISOR: u32 = 1 << 31;
                const FEATURE_MCE: u32 = 1 << 7;
                const FEATURE_X2APIC: u32 = 1 << 21;
                const FEATURE_TSC_DEADLINE: u32 = 1 << 24;
                const FEATURE_APIC: u32 = 1 << 9;
                const MAX_LOGICAL_PROCESSORS_MASK: u32 = 0xff << 16;
                const INITIAL_APIC_ID_MASK: u32 = 0xff << 24;
                let mut res = cpuid!(regs_clone.rax, regs_clone.rcx);
                res.ecx &= !FEATURE_VMX;
                res.ecx |= FEATURE_X2APIC;
                res.ecx &= !FEATURE_TSC_DEADLINE;
                res.ecx |= FEATURE_HYPERVISOR;
                res.edx &= !FEATURE_MCE;
                res.edx |= FEATURE_APIC;
                res.ebx &= !(MAX_LOGICAL_PROCESSORS_MASK | INITIAL_APIC_ID_MASK);
                res.ebx |= 1 << 16;
                res
            }
            0xb | 0x1f => CpuIdResult {
                eax: 0,
                ebx: 0,
                ecx: regs_clone.rcx as u32,
                edx: 0,
            },
            // See SDM Table 3-8. Information Returned by CPUID Instruction (Contd.)
            LEAF_STRUCTURED_EXTENDED_FEATURE_FLAGS_ENUMERATION => {
                let mut res = cpuid!(regs_clone.rax, regs_clone.rcx);
                if regs_clone.rcx == 0 {
                    // Bit 05: WAITPKG.
                    res.ecx.set_bit(5, false); // clear waitpkg
                    // Bit 16: LA57. Supports 57-bit linear addresses and five-level paging if 1.
                    res.ecx.set_bit(16, false); // clear LA57
                }

                res
            }
            LEAF_PROCESSOR_EXTENDED_STATE_ENUMERATION => {
                let state = self.cpu.extended_state().cpuid(regs_clone.rcx as u32);
                CpuIdResult {
                    eax: state.eax,
                    ebx: state.ebx,
                    ecx: state.ecx,
                    edx: state.edx,
                }
            }
            LEAF_HYPERVISOR_INFO => CpuIdResult {
                eax: LEAF_HYPERVISOR_FEATURE,
                ebx: vendor_regs[0],
                ecx: vendor_regs[1],
                edx: vendor_regs[2],
            },
            LEAF_HYPERVISOR_FEATURE => CpuIdResult {
                eax: 0,
                ebx: 0,
                ecx: 0,
                edx: 0,
            },
            EAX_FREQUENCY_INFO => {
                const FALLBACK_TSC_FREQUENCY_MHZ: u32 = 3_000;
                let mut res = cpuid!(regs_clone.rax, regs_clone.rcx);
                if res.eax == 0 {
                    let frequency_mhz = crate::arch::x86_64::policy::host_tsc_frequency_mhz::<H>()
                        .unwrap_or(FALLBACK_TSC_FREQUENCY_MHZ);
                    warn!(
                        "handle_cpuid: Failed to get TSC frequency by CPUID, default to \
                         {frequency_mhz} MHz"
                    );
                    res.eax = frequency_mhz;
                }
                res
            }
            _ => cpuid!(regs_clone.rax, regs_clone.rcx),
        };

        trace!(
            "VM exit: CPUID({:#x}, {:#x}): {:?}",
            regs_clone.rax, regs_clone.rcx, res
        );

        let regs = self.regs_mut();
        regs.rax = res.eax as _;
        regs.rbx = res.ebx as _;
        regs.rcx = res.ecx as _;
        regs.rdx = res.edx as _;
        self.advance_rip(VM_EXIT_INSTR_LEN_CPUID)?;

        Ok(())
    }

    fn handle_xsetbv(&mut self) -> X86VcpuResult {
        const XCR_XCR0: u64 = 0;
        const VM_EXIT_INSTR_LEN_XSETBV: u8 = 3;

        let index = self.cpu.registers().rcx.get_bits(0..32);
        let value = self.cpu.registers().rdx.get_bits(0..32) << 32
            | self.cpu.registers().rax.get_bits(0..32);

        // TODO: get host-supported xcr0 mask by cpuid and reject any guest-xsetbv violating that
        if index == XCR_XCR0 {
            self.cpu.extended_state_mut().set_xcr0(value)?;
            self.advance_rip(VM_EXIT_INSTR_LEN_XSETBV)
        } else {
            // xcr0 only
            x86_err!(Unsupported, "only xcr0 is supported")
        }
    }
}

fn vmx_external_interrupt_allowed(rflags: u64, block_state: u32) -> bool {
    const BLOCKING_BY_STI: u32 = 1 << 0;
    const BLOCKING_BY_MOV_SS: u32 = 1 << 1;

    rflags & x86_64::registers::rflags::RFlags::INTERRUPT_FLAG.bits() != 0
        && block_state & (BLOCKING_BY_STI | BLOCKING_BY_MOV_SS) == 0
}

/// Transfers the IRQ vector acknowledged by VMX to the embedding host.
///
/// `ACK_INTERRUPT_ON_EXIT` consumes the physical interrupt and records its
/// vector in `VMEXIT_INTERRUPTION_INFO`. Enabling host IRQs cannot recreate
/// that interrupt, so the vector must remain explicit until the host performs
/// action dispatch and LAPIC EOI, matching Linux KVM's
/// `handle_external_interrupt_irqoff()` ownership transfer.
fn handle_vmx_external_interrupt_exit<H: X86HostOps, M: ControlMemory>(
    controls: &ax_cpu::virtualization::VmxControls<M>,
) -> X86VcpuResult<X86VmExit> {
    vmx_external_interrupt_exit(
        controls.interrupt_exit_info()?,
        H::dispatch_acknowledged_host_interrupt,
    )
}

fn vmx_external_interrupt_exit(
    info: VmxInterruptInfo,
    dispatch: impl FnOnce(u8),
) -> X86VcpuResult<X86VmExit> {
    if !info.valid || info.int_type != VmxInterruptionType::External {
        return Err(X86VcpuError::InvalidData);
    }
    dispatch(info.vector);
    Ok(X86VmExit::Nothing)
}

impl<H: X86HostOps, M: ControlMemory> Debug for VmxVcpu<H, M> {
    fn fmt(&self, f: &mut Formatter) -> Result {
        f.debug_struct("VmxVcpu")
            .field("guest_regs", self.cpu.registers())
            .field(
                "vmcs",
                &self
                    .cpu
                    .vmx_controls()
                    .expect("VMX policy CPU")
                    .vmcs()
                    .physical_address(),
            )
            .finish_non_exhaustive()
    }
}

impl<H: X86HostOps, M: ControlMemory> VmxVcpu<H, M> {
    pub fn new_with_config(
        vm_id: usize,
        vcpu_id: usize,
        config: X86VcpuCreateConfig<H::Runtime>,
        memory: ax_cpu::virtualization::VmxControlMemory<M>,
        xstate: GuestXstate<M>,
    ) -> X86VcpuResult<Self> {
        Self::new(vm_id, vcpu_id, memory, xstate, config)
    }

    pub fn set_entry(&mut self, entry: X86GuestPhysAddr) -> X86VcpuResult {
        self.entry = Some(entry);
        Ok(())
    }

    pub fn set_nested_page_table(&mut self, config: X86NestedPagingConfig) -> X86VcpuResult {
        if self.nested_page_table_root != Some(config.root_paddr) {
            self.translation_root_dirty = true;
        }
        self.nested_page_table_root = Some(config.root_paddr);
        Ok(())
    }

    pub fn setup(&mut self, config: X86VcpuSetupConfig) -> X86VcpuResult {
        self.entry.ok_or(X86VcpuError::InvalidInput)?;
        self.nested_page_table_root
            .ok_or(X86VcpuError::InvalidInput)?;
        self.prepare_vmcs(config)
    }

    fn handle_port_io_exit(
        &mut self,
        io_info: vmcs::VmxIoExitInfo,
        instruction_len: u8,
    ) -> X86VcpuResult<X86VmExit> {
        let width = X86AccessWidth::try_from(io_info.access_size as usize)
            .map_err(|_| x86_err_type!(InvalidData, "invalid VMX I/O access width"))?;
        let port = X86Port::new(io_info.port);

        if !io_info.is_string {
            // The device service has not run yet, so the owned record carries
            // the retirement `RIP` instead of mutating it here.
            let next_rip = self.next_rip_after(instruction_len)?;
            return Ok(if io_info.is_in {
                X86VmExit::PortIoRead {
                    port,
                    width,
                    next_rip,
                }
            } else {
                X86VmExit::PortIoWrite {
                    port,
                    width,
                    data: self.regs().rax.get_bits(width.bits_range()),
                    next_rip,
                }
            });
        }

        let address_size = self.string_io_address_size()?;
        if io_info.is_repeat && address_size.low(self.regs().rcx) == 0 {
            self.advance_rip(instruction_len)?;
            return Ok(X86VmExit::Nothing);
        }

        let direction = if io_info.is_in {
            X86PortIoDirection::In
        } else {
            X86PortIoDirection::Out
        };
        let index = match direction {
            X86PortIoDirection::In => self.regs().rdi,
            X86PortIoDirection::Out => self.regs().rsi,
        };
        let guest_linear = self
            .cpu
            .vmx_controls()
            .expect("VMX policy CPU")
            .read(VmcsReadOnlyNW::GUEST_LINEAR_ADDR)
            .map_err(X86VcpuError::from)?;
        let guest_paddr =
            self.translate_guest_linear(X86GuestVirtAddr::from_usize(guest_linear))?;
        let next_rip = self
            .cpu
            .vmx_controls()
            .expect("VMX policy CPU")
            .read(VmcsGuestNW::RIP)
            .map_err(X86VcpuError::from)?
            .checked_add(usize::from(instruction_len))
            .ok_or(X86VcpuError::InvalidData)? as u64;
        let decrement = self
            .cpu
            .vmx_controls()
            .expect("VMX policy CPU")
            .read(VmcsGuestNW::RFLAGS)
            .map_err(X86VcpuError::from)? as u64
            & RFlags::DIRECTION_FLAG.bits()
            != 0;

        Ok(X86VmExit::PortIoString(X86PortIoStringExit::new(
            X86PortIoAccess {
                port,
                width,
                direction,
                guest_paddr,
            },
            X86PortIoIteration {
                address_size,
                index,
                count: self.regs().rcx,
                repeat: io_info.is_repeat,
                decrement,
                next_rip,
            },
        )))
    }

    fn string_io_address_size(&self) -> X86VcpuResult<X86AddressSize> {
        let default_bytes = match self.get_cpu_mode() {
            VmCpuMode::Mode64 => 8,
            VmCpuMode::Real => 2,
            VmCpuMode::Protected | VmCpuMode::Compatibility => {
                if self
                    .cpu
                    .vmx_controls()
                    .expect("VMX policy CPU")
                    .read(VmcsGuest32::CS_ACCESS_RIGHTS)
                    .map_err(X86VcpuError::from)?
                    & (1 << 14)
                    != 0
                {
                    4
                } else {
                    2
                }
            }
        };
        let mut cursor = self.gla2gva(X86GuestVirtAddr::from_usize(
            self.cpu
                .vmx_controls()
                .expect("VMX policy CPU")
                .read(VmcsGuestNW::RIP)
                .map_err(X86VcpuError::from)?,
        ));
        let mut address_override = false;

        for _ in 0..15 {
            match self.read_guest_u8(cursor)? {
                0x67 => {
                    address_override = true;
                    cursor += 1;
                }
                0x26 | 0x2e | 0x36 | 0x3e | 0x64 | 0x65 | 0x66 | 0xf0 | 0xf2 | 0xf3 => {
                    cursor += 1;
                }
                0x40..=0x4f if self.get_cpu_mode() == VmCpuMode::Mode64 => cursor += 1,
                0x6c..=0x6f => {
                    let bytes = if address_override {
                        match default_bytes {
                            8 => 4,
                            4 => 2,
                            2 => 4,
                            _ => unreachable!(),
                        }
                    } else {
                        default_bytes
                    };
                    return X86AddressSize::from_bytes(bytes);
                }
                _ => return x86_err!(InvalidData, "VMX string-I/O exit has an invalid opcode"),
            }
        }

        x86_err!(InvalidData, "VMX string-I/O instruction exceeds 15 bytes")
    }

    /// Commits one successfully emulated string-I/O element.
    pub fn complete_port_io_string(&mut self, exit: X86PortIoStringExit) -> X86VcpuResult {
        if exit.instruction_complete() {
            let next_rip =
                usize::try_from(exit.next_rip()).map_err(|_| X86VcpuError::InvalidData)?;
            self.cpu
                .vmx_controls_mut()
                .expect("VMX policy CPU")
                .write(VmcsGuestNW::RIP, next_rip)
                .map_err(X86VcpuError::from)?;
        }
        let regs = self.regs_mut();
        match exit.direction() {
            X86PortIoDirection::In => regs.rdi = exit.updated_index(),
            X86PortIoDirection::Out => regs.rsi = exit.updated_index(),
        }
        if let Some(count) = exit.updated_count() {
            regs.rcx = count;
        }
        Ok(())
    }

    /// Runs this VMX vCPU until an exit is reported to the VMM.
    ///
    /// The caller must keep the vCPU bound to the current host CPU, prevent
    /// migration, and keep host IRQs disabled until this method returns.
    pub fn run(&mut self) -> X86VcpuResult<X86VmExit> {
        match self.inner_run()? {
            Some(exit_info) => Ok(if exit_info.entry_failure {
                X86VmExit::FailEntry {
                    // Todo: get `hardware_entry_failure_reason` somehow.
                    hardware_entry_failure_reason: 0,
                }
            } else {
                match exit_info
                    .exit_reason
                    .map_err(|_| X86VcpuError::Unsupported)?
                {
                    VmxExitReason::Vmcall => {
                        self.advance_rip(exit_info.exit_instruction_length as _)?;
                        X86VmExit::Hypercall {
                            nr: self.regs().rax,
                            args: [
                                self.regs().rdi,
                                self.regs().rsi,
                                self.regs().rdx,
                                self.regs().rcx,
                                self.regs().r8,
                                self.regs().r9,
                            ],
                        }
                    }
                    VmxExitReason::IoInstruction => self.handle_port_io_exit(
                        self.io_exit_info()?,
                        exit_info.exit_instruction_length as u8,
                    )?,
                    VmxExitReason::ExternalInterrupt => handle_vmx_external_interrupt_exit::<H, M>(
                        self.cpu.vmx_controls().expect("VMX policy CPU"),
                    )?,
                    VmxExitReason::PreemptionTimer => {
                        self.handle_vmx_preemption_timer()?;
                        X86VmExit::PreemptionTimer
                    }
                    VmxExitReason::Hlt => {
                        self.advance_rip(exit_info.exit_instruction_length as _)?;
                        X86VmExit::Halt
                    }
                    VmxExitReason::VirtualizedEoi => X86VmExit::InterruptEnd {
                        vector: self.vlapic.handle_eoi(),
                    },
                    VmxExitReason::ApicWrite => {
                        let offset = self.apic_access_exit_info()?.offset as usize;
                        if offset == X86_LOCAL_APIC_EOI_OFFSET {
                            let vector = self.vlapic.handle_eoi();
                            X86VmExit::InterruptEnd { vector }
                        } else {
                            X86VmExit::Nothing
                        }
                    }
                    VmxExitReason::ApicAccess => self.handle_apic_access(&exit_info)?,
                    VmxExitReason::EptViolation => {
                        let info = self.nested_page_fault_info()?;
                        let write = info.access_flags.contains(X86AccessFlags::WRITE);
                        let read = info.access_flags.contains(X86AccessFlags::READ);
                        if (read || write)
                            && let Some((mmio_exit, instruction_len)) = self.decode_ept_mmio_access(
                                &exit_info,
                                info.fault_guest_paddr,
                                write,
                            )
                        {
                            self.retire_decoded_access(mmio_exit, instruction_len)?
                        } else {
                            X86VmExit::NestedPageFault {
                                addr: info.fault_guest_paddr,
                                access_flags: info.access_flags,
                            }
                        }
                    }
                    VmxExitReason::MsrRead => {
                        let msr = self.regs().rcx as u32;
                        if (X2APIC_MSR_BASE..=X2APIC_MSR_END).contains(&msr) {
                            self.handle_apic_msr_access(false, msr)?
                        } else {
                            // The device service has not run yet, so the owned
                            // record carries the retirement `RIP` instead of
                            // advancing it here. `reg` is unused for MSRs.
                            self.retire_decoded_access(
                                X86VmExit::MsrRead {
                                    addr: X86MsrAddr::new(msr as _),
                                    next_rip: UNRESOLVED_NEXT_RIP,
                                },
                                exit_info.exit_instruction_length as u8,
                            )?
                        }
                    }
                    VmxExitReason::MsrWrite => {
                        let msr = self.regs().rcx as u32;
                        if (X2APIC_MSR_BASE..=X2APIC_MSR_END).contains(&msr) {
                            self.handle_apic_msr_access(true, msr)?
                        } else {
                            let value = (self.regs().rax & 0xffff_ffff)
                                | ((self.regs().rdx & 0xffff_ffff) << 32);
                            self.retire_decoded_access(
                                X86VmExit::MsrWrite {
                                    addr: X86MsrAddr::new(msr as _),
                                    value,
                                    next_rip: UNRESOLVED_NEXT_RIP,
                                },
                                exit_info.exit_instruction_length as u8,
                            )?
                        }
                    }
                    _ => {
                        warn!("VMX unsupported VM-Exit: {exit_info:#x?}");
                        warn!("VCpu {self:#x?}");
                        X86VmExit::Halt
                    }
                }
            }),
            None => Ok(X86VmExit::Nothing),
        }
    }

    pub fn bind(&mut self) -> X86VcpuResult {
        self.bind_to_current_processor()
    }

    pub fn unbind(&mut self) -> X86VcpuResult {
        self.unbind_from_current_processor()
    }

    pub fn set_gpr(&mut self, reg: usize, val: usize) {
        self.regs_mut().set_reg_of_index(reg as u8, val as u64);
    }

    /// Sets one byte-encoded guest register while preserving adjacent bytes.
    pub fn set_gpr_byte(&mut self, reg: X86ByteRegister, value: u8) {
        if let Err(err) = self.write_byte_register(reg, value) {
            warn!("failed to write VMX byte register: {err:?}");
        }
    }

    /// Sets one 16-bit guest register while preserving adjacent bytes.
    pub fn set_gpr_word(&mut self, reg: usize, value: u16) {
        if let Err(err) = self.write_word_register(reg, value) {
            warn!("failed to write VMX word register: {err:?}");
        }
    }

    /// Sets the architectural RSP according to the destination-operand width.
    pub fn set_gpr_rsp(&mut self, width: X86AccessWidth, value: u64) {
        let Some(old) = self.read_rsp() else {
            warn!("failed to read VMX RSP for MMIO read");
            return;
        };
        if let Err(err) = self.write_rsp(crate::arch::x86_64::policy::decode::x86_rsp_merge(
            old, width, value,
        )) {
            warn!("failed to write VMX RSP: {err:?}");
        }
    }

    pub fn inject_interrupt(&mut self, vector: usize) -> X86VcpuResult {
        if !(32..=u8::MAX as usize).contains(&vector) {
            return x86_err!(InvalidInput, "fixed APIC vector must be in 32..=255");
        }
        self.queue_fixed_apic_interrupt(vector as u8, false)
    }

    pub fn inject_interrupt_with_trigger(
        &mut self,
        vector: usize,
        level_triggered: bool,
    ) -> X86VcpuResult {
        if !(32..=u8::MAX as usize).contains(&vector) {
            return x86_err!(InvalidInput, "fixed APIC vector must be in 32..=255");
        }
        self.queue_fixed_apic_interrupt(vector as u8, level_triggered)
    }

    pub fn inject_legacy_pic_interrupt(&mut self, vector: u8) -> X86VcpuResult {
        if vector == 0 {
            warn!("legacy PIC interrupt queued with vector 0");
            return x86_err!(InvalidInput, "legacy PIC vector must be nonzero");
        }
        self.queue_event(PendingEvent::external_interrupt(
            vector,
            false,
            PendingEventSource::LegacyPic,
        ));
        Ok(())
    }

    pub fn has_pending_event(&self) -> bool {
        self.injecting_event.is_some()
            || self.reinjection_event.is_some()
            || !self.pending_events.is_empty()
            || self.vlapic.has_pending_timer_interrupt()
    }

    pub fn handle_eoi(&mut self) -> Option<u8> {
        self.vlapic.handle_eoi()
    }

    /// Quiesces this vCPU's local-APIC timer for a task-side VM suspend.
    pub fn suspend_timer(&mut self) -> X86VcpuResult {
        self.vlapic.suspend_timer().map_err(Into::into)
    }

    /// Reinstalls this vCPU's local-APIC timer after a suspend.
    pub fn resume_timer(&mut self) -> X86VcpuResult {
        self.vlapic.resume_timer().map_err(Into::into)
    }

    /// Cancels this vCPU's local-APIC timer and retires its state.
    pub fn stop_timer(&mut self) -> X86VcpuResult {
        self.vlapic.stop_timer().map_err(Into::into)
    }

    pub fn set_return_value(&mut self, val: usize) {
        self.regs_mut().rax = val as u64;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn vmx_requeues_interrupted_external_irq_injection() {
        let pending = PendingEvent::external_interrupt(0x51, true, PendingEventSource::FixedApic);
        let injected = VmxInjectionEvent::pending(pending);
        let vectoring = VmxInterruptInfo {
            vector: pending.vector,
            int_type: VmxInterruptionType::External,
            err_code: None,
            valid: true,
        };

        assert_eq!(
            interrupted_vmx_event(vectoring, 0, Some(injected)),
            Some(injected)
        );
    }

    #[test]
    fn vmx_requeue_preserves_legacy_pic_source() {
        let pending = PendingEvent::external_interrupt(8, false, PendingEventSource::LegacyPic);
        let injected = VmxInjectionEvent::pending(pending);
        let vectoring = VmxInterruptInfo {
            vector: pending.vector,
            int_type: VmxInterruptionType::External,
            err_code: None,
            valid: true,
        };

        let reinjected = interrupted_vmx_event(vectoring, 0, Some(injected)).unwrap();
        assert_eq!(
            reinjected.event.kind,
            PendingEventKind::ExternalInterrupt(PendingEventSource::LegacyPic)
        );
        assert!(!reinjected.event.requires_vlapic_accept());
    }

    #[test]
    fn vmx_classifies_low_legacy_pic_vector_as_external() {
        let pic = PendingEvent::external_interrupt(8, false, PendingEventSource::LegacyPic);

        assert_eq!(
            VmxInjectionEvent::pending(pic).int_type,
            VmxInterruptionType::External
        );
        let double_fault = PendingEvent::exception(8, Some(0));
        assert_eq!(
            VmxInjectionEvent::pending(double_fault).int_type,
            VmxInterruptionType::HardException
        );
    }

    #[test]
    fn vmx_external_irq_ignores_nmi_blocking() {
        let if_enabled = x86_64::registers::rflags::RFlags::INTERRUPT_FLAG.bits();
        let nmi_blocked = 1 << 3;

        assert!(vmx_external_interrupt_allowed(if_enabled, nmi_blocked));
    }

    #[test]
    fn vmx_external_irq_is_dispatched_before_returning_to_the_vmm() {
        let acknowledged = core::cell::Cell::new(None);
        let exit = vmx_external_interrupt_exit(
            VmxInterruptInfo {
                vector: 0x20,
                int_type: VmxInterruptionType::External,
                err_code: None,
                valid: true,
            },
            |vector| acknowledged.set(Some(vector)),
        )
        .unwrap();
        assert!(matches!(exit, X86VmExit::Nothing));
        assert_eq!(acknowledged.get(), Some(0x20));
    }

    #[test]
    fn invalid_vmx_external_irq_is_rejected_before_host_dispatch() {
        let acknowledged = core::cell::Cell::new(None);
        let result = vmx_external_interrupt_exit(
            VmxInterruptInfo {
                vector: 0x20,
                int_type: VmxInterruptionType::Nmi,
                err_code: None,
                valid: true,
            },
            |vector| acknowledged.set(Some(vector)),
        );
        assert!(matches!(result, Err(X86VcpuError::InvalidData)));
        assert_eq!(acknowledged.get(), None);
    }

    #[test]
    fn explicit_irq_injection_does_not_enable_virtual_interrupt_delivery() {
        use vmcs::controls::SecondaryControls;

        let controls = supported_apic_virtualization_controls(|_| true);

        assert!(controls.contains(SecondaryControls::VIRTUALIZE_APIC));
        assert!(!controls.contains(SecondaryControls::VIRTUAL_INTERRUPT_DELIVERY));
    }
}
