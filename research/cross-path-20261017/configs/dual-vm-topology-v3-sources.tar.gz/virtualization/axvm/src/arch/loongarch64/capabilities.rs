//! LoongArch64 implementations of AxVM platform capability hooks.

use super::LoongArch64Arch;
use crate::architecture::{Architecture, GuestBootPlatform, MachinePlatform};

impl Architecture for LoongArch64Arch {}

impl MachinePlatform for LoongArch64Arch {
    const MACHINE_ARCHITECTURE: crate::machine::MachineArchitecture =
        crate::machine::MachineArchitecture::LoongArch64;
}

impl GuestBootPlatform for LoongArch64Arch {
    fn prepare_guest_boot(
        vm_config: &mut crate::config::AxVMConfig,
        vm_create_config: &mut axvmconfig::GuestConfig,
        _provider: &dyn crate::boot::BootImageProvider,
    ) -> crate::AxVmResult<Option<crate::boot::fdt::GuestDtbImage>> {
        if vm_create_config.kernel.effective_boot_protocol() == axvmconfig::VMBootProtocol::Uefi {
            super::boot::prepare_uefi_fdt_config(vm_config, vm_create_config)?;
        } else {
            super::boot::prepare_direct_fdt_config(vm_config, vm_create_config);
        }
        Ok(None)
    }
}
