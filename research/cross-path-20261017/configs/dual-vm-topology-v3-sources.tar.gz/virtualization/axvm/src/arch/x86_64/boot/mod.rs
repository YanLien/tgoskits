//! x86_64 Linux direct boot, BIOS/UEFI firmware, and MP-table image planning.

use std::{format, sync::Arc, vec::Vec};

use axdevice::{FwCfgKernelPayload, FwCfgPlatformConfig, FwCfgRamRegion};
use axvm_types::GuestPhysAddr;
use axvmconfig::{VMBootProtocol, VmMemMappingType};

use super::X86_64Arch;
use crate::{
    architecture::{capabilities::adjustable_guest_boot_policy, *},
    boot::{acpi::*, images::*, *},
    *,
};

mod acpi;
mod boot_params;
mod linux;
mod linux_boot;
mod mptable;
mod multiboot;

impl BootImagePlatform for X86_64Arch {
    fn default_boot_firmware_load_gpa(config: &axvmconfig::GuestConfig) -> Option<GuestPhysAddr> {
        const BUILT_IN_BIOS_LOAD_GPA: usize = 0x8000;

        (config.kernel.boot_firmware_path().is_none()
            && config.kernel.effective_boot_protocol() == VMBootProtocol::Multiboot)
            .then_some(GuestPhysAddr::from(BUILT_IN_BIOS_LOAD_GPA))
    }

    fn load_images_from_filesystem(loader: &mut ImageLoaderCore<'_>) -> AxVmResult {
        let fw_cfg_payload = read_x86_fw_cfg_payload(loader)?;
        let firmware = prepare_x86_firmware(loader, fw_cfg_payload)?;
        if should_direct_boot_linux(&loader.config) {
            let probe = crate::boot::images::fs::kernel_read(
                &loader.config,
                loader.provider,
                linux::HEADER_READ_SIZE,
            );
            if let Ok(data) = probe
                && let Some(header) = detect_linux_image(&data)
            {
                let kernel = crate::boot::images::fs::read_full_image(
                    &loader.config.kernel.kernel_path,
                    loader.provider,
                )?;
                return load_linux_from_filesystem(loader, header, &kernel, &firmware);
            }
        }

        crate::boot::images::fs::load_vm_image(
            &loader.config.kernel.kernel_path,
            loader.kernel_load_gpa,
            &mut *loader.vm,
            loader.provider,
        )?;
        load_boot_image_from_filesystem(loader)?;
        if let Some(ramdisk_path) = loader.config.kernel.ramdisk_path.clone() {
            loader.load_ramdisk_from_filesystem(&ramdisk_path)?;
        }
        Ok(())
    }

    fn guest_boot_policy(
        config: &axvmconfig::GuestConfig,
        provider: &dyn BootImageProvider,
    ) -> crate::config::GuestBootPolicy {
        if !should_direct_boot_linux(config) {
            return adjustable_guest_boot_policy(config);
        }
        let is_linux_image =
            crate::boot::images::fs::kernel_read(config, provider, linux::HEADER_READ_SIZE)
                .ok()
                .and_then(|image| detect_linux_image(&image))
                .is_some();
        if is_linux_image {
            crate::config::GuestBootPolicy::KeepConfigured
        } else {
            adjustable_guest_boot_policy(config)
        }
    }
}

fn load_linux_from_filesystem(
    loader: &mut ImageLoaderCore<'_>,
    header: linux::X86LinuxHeader,
    kernel: &[u8],
    firmware: &PreparedX86Firmware,
) -> AxVmResult {
    adjust_linux_dma_identity_layout(loader);
    let payload = linux_payload(&header, kernel)?;
    let initrd = loader
        .config
        .kernel
        .ramdisk_path
        .as_deref()
        .map(|path| -> AxVmResult<_> {
            let size = crate::boot::images::fs::image_size(path, loader.provider)?;
            Ok(linux::X86LinuxRange::new(
                loader.ramdisk_load_gpa()?.as_usize(),
                size,
            ))
        })
        .transpose()?;
    let layout = linux::X86LinuxLoadLayout::new(
        &header,
        loader.kernel_load_gpa.as_usize(),
        payload.len(),
        initrd,
    )
    .map_err(linux_layout_error)?;

    load_linux_layout(loader, header, layout, kernel, firmware)?;
    load_vm_image_from_memory(payload, loader.kernel_load_gpa, &mut *loader.vm)?;
    if let Some(path) = loader.config.kernel.ramdisk_path.clone() {
        loader.load_ramdisk_from_filesystem(&path)?;
    }
    Ok(())
}

fn load_boot_image_from_filesystem(loader: &mut ImageLoaderCore<'_>) -> AxVmResult {
    if !loader.config.kernel.enable_bios {
        return Ok(());
    }
    if let Some(path) = loader.config.kernel.boot_firmware_path() {
        let load_gpa = loader
            .bios_load_gpa
            .ok_or_else(|| ax_err_type!(NotFound, "boot firmware load address is missing"))?;
        if should_patch_multiboot_info(&loader.config) {
            let bios = crate::boot::images::fs::read_full_image(path, loader.provider)?;
            validate_bios_patch_region(&bios)?;
            load_vm_image_from_memory(&bios, load_gpa, &mut *loader.vm)?;
            load_multiboot_info(loader, &bios, load_gpa)
        } else {
            crate::boot::images::fs::load_vm_image(path, load_gpa, &mut *loader.vm, loader.provider)
        }
    } else if should_load_default_boot_image(loader) {
        let load_gpa = builtin_bios_load_gpa(loader.bios_load_gpa)?;
        load_vm_image_from_memory(multiboot::DEFAULT_BIOS_IMAGE, load_gpa, &mut *loader.vm)?;
        load_multiboot_info(loader, multiboot::DEFAULT_BIOS_IMAGE, load_gpa)
    } else {
        Ok(())
    }
}

fn adjust_linux_dma_identity_layout(loader: &mut ImageLoaderCore<'_>) {
    if !loader.main_memory.is_identical() {
        return;
    }
    let memory_base = loader.main_memory.gpa.as_usize();
    loader.kernel_load_gpa =
        GuestPhysAddr::from(memory_base + loader.config.kernel.kernel_load_addr);
    if let Some(ramdisk_load_addr) = loader.config.kernel.ramdisk_load_addr {
        loader.ramdisk_load_gpa = Some(GuestPhysAddr::from(memory_base + ramdisk_load_addr));
    }
    let config = loader.vm.config_mut();
    config.image_config.kernel_load_gpa = loader.kernel_load_gpa;
    if let Some(load_gpa) = loader.ramdisk_load_gpa
        && let Some(ramdisk) = config.image_config.ramdisk.as_mut()
    {
        ramdisk.load_gpa = load_gpa;
    }
}

struct PreparedX86Firmware {
    plan: acpi::X86FirmwarePlan,
    direct_acpi: AcpiImage,
}

struct X86FwCfgPayload {
    kernel: FwCfgKernelPayload,
    initrd: Option<Arc<[u8]>>,
}

impl X86FwCfgPayload {
    fn empty() -> Self {
        Self {
            kernel: FwCfgKernelPayload::empty(),
            initrd: None,
        }
    }
}

fn x86_fw_cfg_kernel(image: &[u8]) -> AxVmResult<FwCfgKernelPayload> {
    let Some(header) = detect_linux_image(image) else {
        return Ok(FwCfgKernelPayload::unsplit(Arc::from(image)));
    };
    let split = header.payload_offset();
    let (setup, kernel) = image.split_at_checked(split).ok_or_else(|| {
        AxVmError::invalid_config(format!(
            "x86 bzImage setup size {split:#x} exceeds image size {:#x}",
            image.len()
        ))
    })?;
    if kernel.is_empty() {
        return Err(AxVmError::invalid_config(
            "x86 bzImage has an empty protected-mode kernel payload",
        ));
    }
    Ok(FwCfgKernelPayload::split(
        Arc::from(setup),
        Arc::from(kernel),
    ))
}

fn read_x86_fw_cfg_payload(loader: &ImageLoaderCore<'_>) -> AxVmResult<X86FwCfgPayload> {
    if loader.config.kernel.effective_boot_protocol() != VMBootProtocol::Uefi {
        return Ok(X86FwCfgPayload::empty());
    }
    let kernel = crate::boot::images::fs::read_full_image(
        &loader.config.kernel.kernel_path,
        loader.provider,
    )?;
    let initrd = loader
        .config
        .kernel
        .ramdisk_path
        .as_deref()
        .map(|path| crate::boot::images::fs::read_full_image(path, loader.provider))
        .transpose()?;
    Ok(X86FwCfgPayload {
        kernel: x86_fw_cfg_kernel(&kernel)?,
        initrd: initrd.map(Arc::from),
    })
}

fn prepare_x86_firmware(
    loader: &mut ImageLoaderCore<'_>,
    payload: X86FwCfgPayload,
) -> AxVmResult<PreparedX86Firmware> {
    let passthrough_intx_routes = x86_passthrough_intx_routes()?;
    let plan = loader.vm.with_planned_device_graph(|graph| {
        acpi::X86FirmwarePlan::from_graph(
            graph,
            loader.config.base.cpu_num,
            &passthrough_intx_routes,
        )
        .map_err(|error| {
            AxVmError::invalid_config(format!(
                "failed to derive x86 firmware resources from the device graph: {error}"
            ))
        })
    })?;
    let direct_acpi = acpi::build_direct_image(&plan).map_err(acpi_build_error)?;
    debug!(
        "VM[{}] planned {} x86 ACPI tables at {:#x}",
        loader.config.base.id,
        direct_acpi.tables().iter().count(),
        direct_acpi.load_gpa()
    );
    let acpi = acpi::build_fw_cfg_blobs(&plan).map_err(acpi_build_error)?;
    let (fw_cfg_base, fw_cfg_size) = plan.fw_cfg_range().map_err(|error| {
        AxVmError::invalid_config(format!("invalid resolved x86 fw_cfg resources: {error}"))
    })?;
    let ram_regions = fw_cfg_ram_regions(loader);
    loader.vm.add_fw_cfg_device(crate::FwCfgDeviceConfig {
        base: GuestPhysAddr::from(fw_cfg_base),
        size: fw_cfg_size,
        kernel: payload.kernel,
        initrd: payload.initrd,
        cmdline: loader.config.kernel.cmdline.clone(),
        cpu_num: u16::try_from(loader.config.base.cpu_num)
            .map_err(|_| AxVmError::invalid_config("x86 fw_cfg CPU count exceeds 16 bits"))?,
        platform: FwCfgPlatformConfig {
            ram_regions: ram_regions.clone(),
            srat_regions: ram_regions,
            acpi,
        },
    })?;
    Ok(PreparedX86Firmware { plan, direct_acpi })
}

fn x86_passthrough_intx_routes() -> AxVmResult<std::vec::Vec<acpi::X86PciIntxRoute>> {
    #[cfg(feature = "host-fs")]
    {
        let mut routes = std::vec::Vec::new();
        let (device, function, pin, guest_gsi) =
            crate::boot::images::x86_qemu_passthrough_block_intx();
        if function != 0 || !(1..=4).contains(&pin) {
            return Err(AxVmError::invalid_config(
                "x86 passthrough PCI INTx contribution is not a bus-0 function-0 pin",
            ));
        }
        let gsi = u8::try_from(guest_gsi).map_err(|_| {
            AxVmError::invalid_config("x86 passthrough PCI INTx GSI exceeds firmware encoding")
        })?;
        routes.push(acpi::X86PciIntxRoute {
            device,
            pin: pin - 1,
            gsi,
        });
        Ok(routes)
    }
    #[cfg(not(feature = "host-fs"))]
    {
        Ok(std::vec::Vec::new())
    }
}

fn fw_cfg_ram_regions(loader: &ImageLoaderCore<'_>) -> Arc<[FwCfgRamRegion]> {
    let mut regions = loader
        .config
        .kernel
        .memory_regions
        .iter()
        .filter(|region| region.map_type == VmMemMappingType::MapAlloc && region.size != 0)
        .map(|region| FwCfgRamRegion {
            base: region.gpa as u64,
            size: region.size as u64,
        })
        .collect::<Vec<_>>();
    if !regions
        .iter()
        .any(|region| region.base == loader.main_memory.gpa.as_usize() as u64)
    {
        regions.push(FwCfgRamRegion {
            base: loader.main_memory.gpa.as_usize() as u64,
            size: loader.main_memory.size() as u64,
        });
    }
    regions.sort_by_key(|region| region.base);
    regions.into()
}

fn acpi_build_error(error: crate::boot::acpi::AcpiBuildError) -> AxVmError {
    AxVmError::invalid_config(format!("failed to build x86 guest ACPI: {error}"))
}

fn load_linux_layout(
    loader: &mut ImageLoaderCore<'_>,
    header: linux::X86LinuxHeader,
    layout: linux::X86LinuxLoadLayout,
    kernel: &[u8],
    firmware: &PreparedX86Firmware,
) -> AxVmResult {
    loader.vm.set_guest_acpi_tables(
        GuestPhysAddr::from(firmware.direct_acpi.rsdp_gpa() as usize),
        firmware.direct_acpi.bytes().to_vec(),
    )?;
    load_vm_image_from_memory(
        firmware.direct_acpi.bytes(),
        GuestPhysAddr::from(firmware.direct_acpi.load_gpa() as usize),
        &mut *loader.vm,
    )?;
    let boot_params = build_boot_params(loader, header, layout, kernel, firmware)?;
    let boot_stub = linux_boot::build_boot_image(&layout).map_err(|err| {
        ax_err_type!(
            InvalidInput,
            format!("failed to build x86 Linux boot stub: {err:?}")
        )
    })?;
    load_vm_image_from_memory(
        &boot_params,
        layout.boot_params.start.into(),
        &mut *loader.vm,
    )?;
    load_vm_image_from_memory(&boot_stub, layout.boot_stub.start.into(), &mut *loader.vm)?;
    load_vm_image_from_memory(
        &mptable::build(
            firmware.plan.apic_ids(),
            firmware.plan.local_apic_base(),
            firmware.plan.io_apic_base(),
            firmware.plan.pci_intx_routes(),
        ),
        mptable::MP_TABLE_GPA.into(),
        &mut *loader.vm,
    )?;
    let entry = GuestPhysAddr::from(linux_boot::DEFAULT_LINUX_BOOT_LOAD_GPA);
    let config = loader.vm.config_mut();
    config.cpu_config.bsp_entry = entry;
    config.cpu_config.ap_entry = entry;
    Ok(())
}

fn build_boot_params(
    loader: &ImageLoaderCore<'_>,
    header: linux::X86LinuxHeader,
    layout: linux::X86LinuxLoadLayout,
    kernel: &[u8],
    firmware: &PreparedX86Firmware,
) -> AxVmResult<[u8; linux::BOOT_PARAMS_SIZE]> {
    let mut builder = boot_params::BootParamsBuilder::new(
        kernel,
        header,
        layout,
        linux::X86LinuxRange::new(loader.main_memory.gpa.as_usize(), loader.main_memory.size()),
    );
    let command_line = loader.config.kernel.cmdline.as_deref().ok_or_else(|| {
        ax_err_type!(
            InvalidInput,
            "x86 Linux direct boot requires kernel.cmdline in the VM config"
        )
    })?;
    builder.set_command_line(command_line).map_err(|err| {
        ax_err_type!(
            InvalidInput,
            format!("invalid x86 Linux command line: {err:?}")
        )
    })?;
    builder.set_acpi_rsdp_addr(firmware.direct_acpi.rsdp_gpa());
    builder.add_reserved_range(linux::X86LinuxRange::new(
        firmware.direct_acpi.load_gpa() as usize,
        firmware.direct_acpi.bytes().len(),
    ));
    for memory in &loader.config.kernel.memory_regions {
        if memory.map_type == VmMemMappingType::MapAlloc {
            builder.add_ram_range(linux::X86LinuxRange::new(memory.gpa, memory.size));
        }
    }
    builder.add_reserved_range(linux::X86LinuxRange::new(
        firmware.plan.io_apic_base() as usize,
        0x1000,
    ));
    let (ecam_base, ecam_size) = firmware.plan.pci_ecam_range();
    builder.add_reserved_range(linux::X86LinuxRange::new(
        ecam_base as usize,
        ecam_size as usize,
    ));
    builder.add_reserved_range(mptable::reserved_range());
    builder.build().map_err(|err| {
        ax_err_type!(
            InvalidInput,
            format!("failed to build x86 boot_params: {err:?}")
        )
    })
}

fn load_multiboot_info(
    loader: &mut ImageLoaderCore<'_>,
    bios_image: &[u8],
    bios_load_gpa: GuestPhysAddr,
) -> AxVmResult {
    const INFO_GPA: usize = 0x6000;
    const MMAP_GPA: usize = 0x6040;
    let mem_base = loader.main_memory.gpa.as_usize() as u64;
    let mem_size = loader.main_memory.size() as u64;
    let mut info = [0u8; 52];
    write_u32(&mut info, 0, (1 << 0) | (1 << 6));
    write_u32(&mut info, 4, 639);
    write_u32(
        &mut info,
        8,
        (mem_size.saturating_sub(0x100000) / 1024) as u32,
    );
    write_u32(&mut info, 44, 24);
    write_u32(&mut info, 48, MMAP_GPA as u32);
    let mut mmap = [0u8; 24];
    write_u32(&mut mmap, 0, 20);
    write_u64(&mut mmap, 4, mem_base);
    write_u64(&mut mmap, 12, mem_size);
    write_u32(&mut mmap, 20, 1);
    validate_bios_patch_region(bios_image)?;
    load_vm_image_from_memory(&info, INFO_GPA.into(), &mut *loader.vm)?;
    load_vm_image_from_memory(&mmap, MMAP_GPA.into(), &mut *loader.vm)?;
    load_vm_image_from_memory(
        &(INFO_GPA as u32).to_le_bytes(),
        (bios_load_gpa.as_usize() + multiboot::AXVM_BIOS_EBX_IMM_OFFSET).into(),
        &mut *loader.vm,
    )
}

fn should_direct_boot_linux(config: &axvmconfig::GuestConfig) -> bool {
    !config.kernel.enable_bios && config.kernel.effective_boot_protocol() == VMBootProtocol::Direct
}

fn should_patch_multiboot_info(config: &axvmconfig::GuestConfig) -> bool {
    config.kernel.effective_boot_protocol() == VMBootProtocol::Multiboot
}

fn should_load_default_boot_image(loader: &ImageLoaderCore<'_>) -> bool {
    loader.config.kernel.enable_bios
        && loader.config.kernel.boot_firmware_path().is_none()
        && loader.config.kernel.effective_boot_protocol() == VMBootProtocol::Multiboot
}

fn detect_linux_image(image: &[u8]) -> Option<linux::X86LinuxHeader> {
    linux::X86LinuxHeader::parse(image).ok()
}

fn linux_payload<'a>(header: &linux::X86LinuxHeader, image: &'a [u8]) -> AxVmResult<&'a [u8]> {
    image.get(header.payload_offset()..).ok_or_else(|| {
        ax_err_type!(
            InvalidInput,
            format!(
                "x86 Linux bzImage payload offset {:#x} exceeds image size {:#x}",
                header.payload_offset(),
                image.len()
            )
        )
    })
}

fn linux_layout_error(err: linux::X86LinuxLayoutError) -> AxVmError {
    ax_err_type!(
        InvalidInput,
        format!("invalid x86 Linux memory layout: {err:?}")
    )
}

fn builtin_bios_load_gpa(configured: Option<GuestPhysAddr>) -> AxVmResult<GuestPhysAddr> {
    let default = GuestPhysAddr::from(multiboot::DEFAULT_BIOS_LOAD_GPA);
    match configured {
        Some(gpa) if gpa != default => Err(ax_err_type!(
            InvalidInput,
            format!(
                "built-in x86 BIOS must be loaded at GPA {:#x}, but bios_load_addr is {:#x}",
                default.as_usize(),
                gpa.as_usize()
            )
        )),
        Some(gpa) => Ok(gpa),
        None => Ok(default),
    }
}

fn validate_bios_patch_region(bios: &[u8]) -> AxVmResult {
    let patch_end = multiboot::AXVM_BIOS_EBX_IMM_OFFSET + std::mem::size_of::<u32>();
    if bios.len() < patch_end
        || bios[multiboot::AXVM_BIOS_EBX_IMM_OFFSET - 1] != multiboot::MOV_EBX_IMM32_OPCODE
    {
        return Err(ax_err_type!(
            InvalidInput,
            "x86 BIOS image does not match the AxVM multiboot patch layout"
        ));
    }
    Ok(())
}

fn write_u32(buffer: &mut [u8], offset: usize, value: u32) {
    buffer[offset..offset + 4].copy_from_slice(&value.to_le_bytes());
}

fn write_u64(buffer: &mut [u8], offset: usize, value: u64) {
    buffer[offset..offset + 8].copy_from_slice(&value.to_le_bytes());
}

#[cfg(test)]
mod tests {
    use super::*;

    struct FileImageProvider(Vec<u8>);
    impl BootImageProvider for FileImageProvider {
        fn read_file(&self, _path: &str) -> AxVmResult<Vec<u8>> {
            Ok(self.0.clone())
        }
    }
    fn file_provider_with_kernel(kernel: Vec<u8>) -> FileImageProvider {
        FileImageProvider(kernel)
    }

    fn linux_header_image() -> Vec<u8> {
        let mut image = vec![0u8; linux::HEADER_READ_SIZE];
        image[0x1fe..0x200].copy_from_slice(&0xaa55u16.to_le_bytes());
        image[0x202..0x206].copy_from_slice(b"HdrS");
        image
    }

    #[test]
    fn built_in_bios_uses_default_gpa_when_unspecified() {
        assert_eq!(
            builtin_bios_load_gpa(None).unwrap(),
            GuestPhysAddr::from(multiboot::DEFAULT_BIOS_LOAD_GPA)
        );
    }

    #[test]
    fn built_in_bios_accepts_explicit_default_gpa() {
        let default = GuestPhysAddr::from(multiboot::DEFAULT_BIOS_LOAD_GPA);
        assert_eq!(builtin_bios_load_gpa(Some(default)).unwrap(), default);
    }

    #[test]
    fn built_in_bios_rejects_non_default_gpa() {
        let invalid = GuestPhysAddr::from(multiboot::DEFAULT_BIOS_LOAD_GPA + 0x1000);
        assert!(builtin_bios_load_gpa(Some(invalid)).is_err());
    }

    #[test]
    fn legacy_bios_config_uses_multiboot_patch() {
        let mut config = axvmconfig::GuestConfig::default();
        config.kernel.enable_bios = true;
        assert!(should_patch_multiboot_info(&config));
    }

    #[test]
    fn uefi_config_skips_multiboot_patch() {
        let mut config = axvmconfig::GuestConfig::default();
        config.kernel.enable_bios = true;
        config.kernel.boot_protocol = Some(VMBootProtocol::Uefi);
        assert!(!should_patch_multiboot_info(&config));
    }

    #[test]
    fn linux_direct_boot_requires_direct_protocol_without_bios() {
        let mut config = axvmconfig::GuestConfig::default();
        assert!(should_direct_boot_linux(&config));

        config.kernel.enable_bios = true;
        assert!(!should_direct_boot_linux(&config));

        config.kernel.boot_protocol = Some(VMBootProtocol::Uefi);
        assert!(!should_direct_boot_linux(&config));

        config.kernel.boot_protocol = Some(VMBootProtocol::Direct);
        assert!(!should_direct_boot_linux(&config));

        config.kernel.enable_bios = false;
        assert!(should_direct_boot_linux(&config));
    }

    #[test]
    fn typed_boot_policy_distinguishes_direct_kernel_images() {
        let config = axvmconfig::GuestConfig::default();
        let linux_provider = file_provider_with_kernel(linux_header_image());

        assert_eq!(
            X86_64Arch::guest_boot_policy(&config, &linux_provider),
            crate::config::GuestBootPolicy::KeepConfigured
        );
        let other_provider = file_provider_with_kernel(vec![0u8; linux::HEADER_READ_SIZE]);
        assert_eq!(
            X86_64Arch::guest_boot_policy(&config, &other_provider),
            crate::config::GuestBootPolicy::AdjustKernelForBootProtocol {
                protocol: VMBootProtocol::Direct,
            }
        );
    }

    #[cfg(feature = "host-fs")]
    #[test]
    fn host_fs_passthrough_route_reaches_the_final_firmware_tables() {
        use crate::vm::prepare::device_plan::ArchitectureVmPlan;

        let config = AxVMConfig::default_for_test(0, "host-fs-firmware-route");
        let device_plan = super::vm::test_plan_devices(&config).unwrap();
        let graph = ArchitectureVmPlan::devices(&device_plan).graph();
        let routes = x86_passthrough_intx_routes().unwrap();
        let firmware = acpi::X86FirmwarePlan::from_graph(graph, 1, &routes).unwrap();
        let route = routes[0];

        let dsdt = acpi::build_dsdt(&firmware).unwrap();
        assert!(
            dsdt.windows(4)
                .any(|window| window == route.acpi_address().to_le_bytes())
        );

        let mp_table = mptable::build(
            firmware.apic_ids(),
            firmware.local_apic_base(),
            firmware.io_apic_base(),
            firmware.pci_intx_routes(),
        );
        assert!(mp_table.windows(8).any(|entry| {
            entry[0] == 3
                && entry[4] == 0
                && entry[5] == route.mp_source_irq()
                && entry[7] == route.gsi
        }));
    }
}
