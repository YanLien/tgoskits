# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.18.1](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.18.0...ax-driver-v0.18.1) - 2026-09-22

### Added

- *(virtio-gpu)* integrate virgl DRM on current dev ([#2483](https://github.com/rcore-os/tgoskits/pull/2483))

## [0.18.0](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.17.0...ax-driver-v0.18.0) - 2026-09-21

### Added

- *(pwm)* unify BSP-backed drivers and Starry integration ([#2437](https://github.com/rcore-os/tgoskits/pull/2437))

## [0.17.0](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.16.0...ax-driver-v0.17.0) - 2026-09-18

### Fixed

- *(ci)* restore RK3588 NPU inference and require complete workload success ([#2441](https://github.com/rcore-os/tgoskits/pull/2441))
- *(rknpu)* enforce per-owner and per-device GEM allocation quotas ([#2424](https://github.com/rcore-os/tgoskits/pull/2424))
- *(ci)* fix debugfs test execution and virtio input startup ([#2396](https://github.com/rcore-os/tgoskits/pull/2396))
- *(ax-driver)* keep PCI INTx unmasked for virtio input probe ([#2353](https://github.com/rcore-os/tgoskits/pull/2353))

### Other

- *(repo)* remove nonfunctional and redundant test assertions ([#2440](https://github.com/rcore-os/tgoskits/pull/2440))

## [0.16.0](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.15.0...ax-driver-v0.16.0) - 2026-09-13

### Fixed

- *(rknpu)* copy and validate user task arrays before NPU submit ([#2327](https://github.com/rcore-os/tgoskits/pull/2327))

## [0.15.0](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.14.0...ax-driver-v0.15.0) - 2026-09-11

### Fixed

- *(axvisor)* restore COM1 console and preserve guest output order ([#2311](https://github.com/rcore-os/tgoskits/pull/2311))
- *(rknpu)* add timeout error handling and update ioctl error mapping ([#2324](https://github.com/rcore-os/tgoskits/pull/2324))

## [0.14.0](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.13.3...ax-driver-v0.14.0) - 2026-09-09

### Added

- *(trait-ffi)* [**breaking**] maintain and extend static interfaces with syn 3 ([#2300](https://github.com/rcore-os/tgoskits/pull/2300))
- *(aic8800)* integrate AKA WPA2 Wi-Fi and iperf validation ([#2222](https://github.com/rcore-os/tgoskits/pull/2222))

### Fixed

- *(jpeg)* validate MPP DMA ranges against imported dma-bufs ([#2289](https://github.com/rcore-os/tgoskits/pull/2289))
- *(starry)* enforce warning-free builds ([#2244](https://github.com/rcore-os/tgoskits/pull/2244))
- *(ax-driver)* align RK3588 DWCMSHC clock setup ([#2242](https://github.com/rcore-os/tgoskits/pull/2242))

### Other

- *(repo)* remove duplicated tests and configuration snapshots ([#2326](https://github.com/rcore-os/tgoskits/pull/2326))
- *(repo)* continue removing nonfunctional test scaffolding ([#2307](https://github.com/rcore-os/tgoskits/pull/2307))
- *(ax-task)* rebuild scheduler and runtime ownership ([#1775](https://github.com/rcore-os/tgoskits/pull/1775))

## [0.13.3](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.13.2...ax-driver-v0.13.3) - 2026-08-27

### Other

- *(sdmmc)* unify SDIO protocol and AIC8800 driver ([#2201](https://github.com/rcore-os/tgoskits/pull/2201))
- *(runtime)* make IRQ and multitasking mandatory ([#2188](https://github.com/rcore-os/tgoskits/pull/2188))
- *(ax-net)* add queue-level NAPI runtime ([#2178](https://github.com/rcore-os/tgoskits/pull/2178))

## [0.13.2](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.13.1...ax-driver-v0.13.2) - 2026-08-25

### Fixed

- *(ax-driver)* attribute RK3588 governor busy by FDT cpu topology ([#2165](https://github.com/rcore-os/tgoskits/pull/2165))

## [0.13.1](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.13.0...ax-driver-v0.13.1) - 2026-08-25

### Other

- FDT IRQ binding validation ([#2062](https://github.com/rcore-os/tgoskits/pull/2062))

## [0.13.0](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.12.3...ax-driver-v0.13.0) - 2026-08-20

### Added

- *(dma-api)* [**breaking**] add device DMA coherency with uncached-alias remap ([#2106](https://github.com/rcore-os/tgoskits/pull/2106))
- *(axvisor)* add dual-guest virtio-net support ([#1927](https://github.com/rcore-os/tgoskits/pull/1927))

### Fixed

- *(sdmmc)* align Rockchip reset failure lifecycle ([#1987](https://github.com/rcore-os/tgoskits/pull/1987))
- *(visionfive2)* restore booti and SD rootfs boot ([#1954](https://github.com/rcore-os/tgoskits/pull/1954))

### Other

- *(axtest)* standardize Cargo and QEMU test flow ([#2088](https://github.com/rcore-os/tgoskits/pull/2088))
- *(serial)* establish bounded owner-affine UART runtime ([#2076](https://github.com/rcore-os/tgoskits/pull/2076))
- *(errors)* introduce domain-owned error boundaries ([#2024](https://github.com/rcore-os/tgoskits/pull/2024))
- *(rdrive)* add fdt_ref() to borrow the device tree without cloning ([#2004](https://github.com/rcore-os/tgoskits/pull/2004))
- *(sync)* unify lock primitives in ax-sync ([#1956](https://github.com/rcore-os/tgoskits/pull/1956))

## [0.12.3](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.12.2...ax-driver-v0.12.3) - 2026-08-09

### Fixed

- *(rknpu)* set RK3588 NPU clock to 800 MHz ([#1908](https://github.com/rcore-os/tgoskits/pull/1908))
- *(dwmmc)* restore RK3588 SD card boot ([#1830](https://github.com/rcore-os/tgoskits/pull/1830))

### Other

- *(axvm)* unify guest devices and AArch64 timer ownership ([#1717](https://github.com/rcore-os/tgoskits/pull/1717))

## [0.12.2](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.12.1...ax-driver-v0.12.2) - 2026-08-03

### Added

- *(ahci-driver)* add portable multi-disk AHCI support ([#1795](https://github.com/rcore-os/tgoskits/pull/1795))
- *(rockchip)* add RK3576 ROCK 4D support ([#1704](https://github.com/rcore-os/tgoskits/pull/1704))
- *(cpufreq)* RK3588 ondemand CPU DVFS with voltage calibration ([#1657](https://github.com/rcore-os/tgoskits/pull/1657))
- *(axvisor)* support StarryOS guest on Orange Pi 5 Plus ([#1684](https://github.com/rcore-os/tgoskits/pull/1684))

### Fixed

- *(dma-api)* retire legacy axdma release paths ([#1796](https://github.com/rcore-os/tgoskits/pull/1796))

### Other

- *(block)* adopt IRQ-driven multi-queue runtime ([#1768](https://github.com/rcore-os/tgoskits/pull/1768))
- enhance axtest coverage for various starry-kernel contracts ([#1674](https://github.com/rcore-os/tgoskits/pull/1674))

### Changed

- Defer SD/eMMC protocol initialization to the block hctx and configure every
  migrated controller through an owned `dma-api` capability.
- Restore the existing SD/eMMC configuration surface on top of the migrated
  CV181x, SDHCI, DWMMC, JH7110, Phytium MCI, and K230 implementations.
- Replace the LS2K1000 AHCI synchronous polling adapter with a single-slot
  IRQ-driven queue that owns command and request DMA through `dma-api`.
- Bind NVMe admin and I/O vectors independently and enable each MSI-X source
  only after its non-reentrant handler is installed.
- Keep the NVMe INTx acknowledgement path lock-free and ignore AHCI port status
  outside the controller's enabled completion, error, and link event mask.

### Removed

- Remove unreachable BCM2835 synchronous glue and the legacy `UnsafeCell`
  shared-driver adapter.

## [0.12.1](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.12.0...ax-driver-v0.12.1) - 2026-07-23

### Added

- *(rockchip-rga)* add the RK3588 RGA2 2D accelerator driver with /dev/rga and dma-heap ([#1388](https://github.com/rcore-os/tgoskits/pull/1388))

### Other

- *(ax-runtime)* centralize UART scheduling ([#1675](https://github.com/rcore-os/tgoskits/pull/1675))

## [0.12.0](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.11.3...ax-driver-v0.12.0) - 2026-07-10

### Added

- *(crab-usb)* add SG2002 DWC2 host axtest ([#1496](https://github.com/rcore-os/tgoskits/pull/1496))
- *(msi)* add hierarchical MSI-X irq domains ([#1526](https://github.com/rcore-os/tgoskits/pull/1526))

## [0.11.3](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.11.2...ax-driver-v0.11.3) - 2026-07-08

### Other

- updated the following local packages: axklib, ax-alloc

## [0.11.2](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.11.1...ax-driver-v0.11.2) - 2026-07-08

### Other

- updated the following local packages: ax-alloc, axklib

## [0.11.1](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.11.0...ax-driver-v0.11.1) - 2026-07-08

### Other

- updated the following local packages: ax-kspin, dma-api, rd-net, aic8800, rdrive, ax-alloc, axklib, arm-scmi-rs, crab-usb, rdif-block, sdmmc-protocol, sdhci-host, cv181x-sdhci, dwmmc-host, eth-intel, nvme-driver, phytium-mci-host, ramdisk, realtek-rtl8125, rockchip-jpeg, rockchip-npu, rockchip-rga, rockchip-soc, starfive-jh7110-dwmmc

## [0.11.0](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.10.0...ax-driver-v0.11.0) - 2026-07-07

### Added

- *(rdrive)* apply assigned clocks before FDT probe ([#1527](https://github.com/rcore-os/tgoskits/pull/1527))
- *(starfive-jh7110-dwmmc)* add IRQ-driven host ([#1524](https://github.com/rcore-os/tgoskits/pull/1524))
- *(msi)* add aarch64 MSI-X registration ([#1522](https://github.com/rcore-os/tgoskits/pull/1522))
- *(rdrive)* add FDT power-domain probing ([#1515](https://github.com/rcore-os/tgoskits/pull/1515))
- *(starry)* support rtnetlink IPv4 configuration ([#1497](https://github.com/rcore-os/tgoskits/pull/1497))
- *(cv181x-sdhci)* add SG2002 SD driver ([#1482](https://github.com/rcore-os/tgoskits/pull/1482))
- *(crab-usb)* add RK3588 EHCI USB2 host ([#1481](https://github.com/rcore-os/tgoskits/pull/1481))
- *(starry-kernel)* add RK3588 PWM sysfs support ([#1468](https://github.com/rcore-os/tgoskits/pull/1468))

### Fixed

- *(block)* drive virtio-blk completions by IRQ ([#1512](https://github.com/rcore-os/tgoskits/pull/1512))
- *(starry)* apply termios serial format and handle tty drain ioctls ([#1484](https://github.com/rcore-os/tgoskits/pull/1484))

### Other

- *(drivers)* split Rockchip reset capability ([#1509](https://github.com/rcore-os/tgoskits/pull/1509))
- *(platforms)* move someboot and somehal-macros and add documents ([#1485](https://github.com/rcore-os/tgoskits/pull/1485))
- *(sdmmc-protocol)* split SDIO and RDIF capability modules ([#1486](https://github.com/rcore-os/tgoskits/pull/1486))
- remove static platform and axconfig generation, make dynamic platform the only path ([#1478](https://github.com/rcore-os/tgoskits/pull/1478))

## [0.10.0](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.9.0...ax-driver-v0.10.0) - 2026-07-02

### Added

- *(rockchip-jpeg)* add RK3588 hardware JPEG decoder (VDPU720) with MPP /dev/mpp_service ([#1456](https://github.com/rcore-os/tgoskits/pull/1456))
- *(rdif-pinctrl)* add FDT pinctrl apply support ([#1433](https://github.com/rcore-os/tgoskits/pull/1433))

### Fixed

- *(ci)* prevent Starry qemu hangs in IRQ paths ([#1431](https://github.com/rcore-os/tgoskits/pull/1431))
- *(irq)* close domain runtime review gaps

### Other

- *(ax-driver)* remove static platform compatibility ([#1463](https://github.com/rcore-os/tgoskits/pull/1463))
- *(rdrive)* apply default FDT pinctrl before probe ([#1458](https://github.com/rcore-os/tgoskits/pull/1458))
- *(irq-framework)* require boxed IRQ callbacks ([#1452](https://github.com/rcore-os/tgoskits/pull/1452))
- *(rdif-block)* enable boxed sdmmc irq flow ([#1446](https://github.com/rcore-os/tgoskits/pull/1446))
- *(net)* split IRQ handlers from NIC queues ([#1435](https://github.com/rcore-os/tgoskits/pull/1435))
- *(ax-runtime)* resolve device IRQ bindings to IrqId

## [0.9.0](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.8.2...ax-driver-v0.9.0) - 2026-06-27

### Added

- *(rdif-block)* add owned DMA queue primitives
- *(ax-driver)* add VisionFive2 dynamic rtc and mmc ([#1353](https://github.com/rcore-os/tgoskits/pull/1353))

### Fixed

- *(locking)* remove spin mutex usage from kernel paths ([#1380](https://github.com/rcore-os/tgoskits/pull/1380))
- *(ax-driver)* serialize virtio-net queue access ([#1392](https://github.com/rcore-os/tgoskits/pull/1392))
- *(rknpu)* honor GEM cache flags for mmap ([#1364](https://github.com/rcore-os/tgoskits/pull/1364))

### Other

- *(ax-driver)* use native SDMMC RDIF devices
- *(serial)* align IRQ model with dev ([#1265](https://github.com/rcore-os/tgoskits/pull/1265))

## [0.8.2](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.8.1...ax-driver-v0.8.2) - 2026-06-23

### Other

- updated the following local packages: rd-net, aic8800, ax-kspin, dma-api, ax-alloc, axklib, some-serial, crab-usb, dwmmc-host, eth-intel, rdif-block, nvme-driver, phytium-mci-host, ramdisk, realtek-rtl8125, rockchip-npu, rockchip-rga, rockchip-soc, sdhci-host

## [0.8.1](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.8.0...ax-driver-v0.8.1) - 2026-06-22

### Added

- *(starry)* add Wayland app case ([#1160](https://github.com/rcore-os/tgoskits/pull/1160))
- *(rockchip-rga)* add dry-run command buffer ([#1248](https://github.com/rcore-os/tgoskits/pull/1248))
- AIC8800 Wi-Fi SoftAP for SG2002 (LicheeRV Nano) ([#1185](https://github.com/rcore-os/tgoskits/pull/1185))

### Other

- *(ax-runtime)* adapt submit-poll fs block irq registration ([#1228](https://github.com/rcore-os/tgoskits/pull/1228))

## [0.8.0](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.7.1...ax-driver-v0.8.0) - 2026-06-12

### Added

- *(ax-driver)* add dynamic platform rtc support ([#1242](https://github.com/rcore-os/tgoskits/pull/1242))

### Fixed

- *(somehal)* route LoongArch ACPI GSIs through PCH-PIC

### Other

- *(irq)* carry ACPI IRQ routing metadata
- *(ax-driver)* normalize FDT PCI IRQ source resolution
- *(ax-driver)* register devices with binding info
- *(rdrive)* carry probe context and PCI INTx routes

## [0.7.1](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.7.0...ax-driver-v0.7.1) - 2026-06-11

### Fixed

- *(kernel)* harden early allocation and virtio PCI setup

## [0.7.0](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.6.1...ax-driver-v0.7.0) - 2026-06-09

### Added

- *(std)* unify std-aware ArceOS builds ([#1080](https://github.com/rcore-os/tgoskits/pull/1080))
- *(somehal)* register x86 ACPI IOAPIC through rdrive ([#1155](https://github.com/rcore-os/tgoskits/pull/1155))

### Fixed

- *(ci)* switch x86_64 defaults to dynamic platform ([#1024](https://github.com/rcore-os/tgoskits/pull/1024))

### Other

- *(ax-driver)* remove redundant mmio cfg gate ([#1100](https://github.com/rcore-os/tgoskits/pull/1100))

## [0.6.1](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.6.0...ax-driver-v0.6.1) - 2026-06-03

### Added

- *(dma-api)* add high-level dma sync helpers ([#1028](https://github.com/rcore-os/tgoskits/pull/1028))
- *(irq)* introduce shared IRQ framework ([#1065](https://github.com/rcore-os/tgoskits/pull/1065))
- *(starryos)* add QEMU K230 boot support ([#1046](https://github.com/rcore-os/tgoskits/pull/1046))
- *(riscv64)* support dynamic platform on QEMU and SG2002 ([#961](https://github.com/rcore-os/tgoskits/pull/961))
- *(some-serial)* add Rockchip FIQ debugger UART ([#980](https://github.com/rcore-os/tgoskits/pull/980))

### Other

- *(platform)* migrate riscv64 qemu to dynamic platform ([#1085](https://github.com/rcore-os/tgoskits/pull/1085))
- *(platform)* remove static aarch64 platforms ([#1074](https://github.com/rcore-os/tgoskits/pull/1074))
- *(rdif-block)* switch block drivers to submit poll ([#976](https://github.com/rcore-os/tgoskits/pull/976))
- *(ax-alloc)* remove ax-allocator dependency, simplify to TLSF/buddy-slab backends ([#987](https://github.com/rcore-os/tgoskits/pull/987))

## [0.6.0](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.5.14...ax-driver-v0.6.0) - 2026-05-19

### Fixed

- *(starry)* weston bringup fixes + IRQ wakers + AF_UNIX cmsg byte marks ([#509](https://github.com/rcore-os/tgoskits/pull/509))

### Other

- Refactor Clippy integration and enhance package handling ([#738](https://github.com/rcore-os/tgoskits/pull/738))

## [0.5.14](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.5.13...ax-driver-v0.5.14) - 2026-05-15

### Other

- updated the following local packages: ax-driver-input, ax-driver-virtio, ax-alloc, ax-config, axplat-dyn, ax-hal, ax-driver-net, ax-dma

## [0.5.12](https://github.com/rcore-os/tgoskits/compare/ax-driver-v0.5.11...ax-driver-v0.5.12) - 2026-04-27

### Other

- updated the following local packages: ax-alloc
